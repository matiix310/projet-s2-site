using ProjS2.Utils;

namespace ProjS2
{
    public class Canvas
    {
        /// <summary>The global height of the canvas.</summary>
        private readonly int _height;
        /// <summary>The global width of the canvas.</summary>
        private readonly int _width;
        /// <summary>The width of the left panel.</summary>
        private readonly int _bufferWidth;
        /// <summary>The default cursor location. DO NOT CHANGE IF YOU DON'T KNOW WHAT YOUR'E DOING.</summary>
        private readonly (int x, int y) _defaultCursorLocation;

        /// <summary>the text representation of the canvas.</summary>
        private string[] _board;

        /// <summary>The primary class to interact with the graphical component of the terminal.</summary>
        /// <param name="width">The width of the canvas.</param>
        /// <param name="height">The height of the canvas.</param>
        /// <param name="bufferWidth">The width of the left panel.</param>
        public Canvas(int width, int height, int bufferWidth) {
            this._height = height;
            this._width = width;
            this._bufferWidth = bufferWidth;
            this._defaultCursorLocation = (0, 0);

            this._board = InitBoard(width, height);

            Clear();
            // Linux test
//            Console.SetWindowSize(this.Width, this.Height);
//            Console.SetBufferSize(this.Width, this.Height);
        }

        /// <summary>Returns a new blank board of the specified dimensions.</summary>
        /// <param name="width">the width of the create board.</param>
        /// <param name="height">the height of the create board.</param>
        private string[] InitBoard(int width, int height) {
            string[] boardTemp = new string[height];
            for (int y = 0; y < height; y++) {
                boardTemp[y] = new String(' ', width);
            }

            return boardTemp;
        }

        public int GetHeight() => this._height;

        public int GetWidth() => this._width;

        public string[] GetBoard() => this._board;

        public int GetBufferWidth() => this._bufferWidth;

        /// <summary>Create a rectangle of the specified dimensions with the given character.</summary>
        /// <param name="width">The width of the rectangle.</param>
        /// <param name="height">The height of the rectangle?</param>
        /// <param name="defaultValue">The character that will fill the created rectangle.</param>
        private string[] CreateRectangle(int width, int height, char defaultValue) {
            string[] str = new string[height];

            for (int i = 0; i < height; i++) str[i] = new String(defaultValue, width);

            return str;
        }

        /// <summary>Clear the console, remove the cursor and set the title of the prompt.</summary>
        public void DrawCanvas() {
            Clear();
            Console.Title = "Termin@l game";
            Console.CursorVisible = false;
        }

        /// <summary>Clear the console buffer.</summary>
        public void Clear() {
            this._board = InitBoard(this._width, _height);
            Console.Clear();
        }

        /// <summary>Write a string (at the given position).</summary>
        /// <param name="txt">The string you want to display.</param>
        /// <param name="x0">The x location.</param>
        /// <param name="y0">The y location.</param>
        public void Write(string? txt, int x0, int y0) {
            if (txt != null && x0 < this._width && y0 < this._height && x0 >= 0 && y0 >= 0) {

                string[] splited = txt.Split('\n');
                string[] boardCp = this._board;

                for (int y = 0; y < splited.Length; y++) {
                    boardCp[y+y0] = boardCp[y+y0].Substring(0, x0) + splited[y] + boardCp[y+y0].Substring(x0 + splited[y].Length);
                }

                this._board = boardCp;
            }
        }

        /// <summary>Write a string without the spaces (at the given position) and replace 'ç' with spaces.</summary>
        /// <param name="txt">The string you want to display.</param>
        /// <param name="x0">The x location.</param>
        /// <param name="y0">The y location.</param>
        public void WriteWithAlpha(string ?txt, int x0, int y0)
        {
            if (txt is null)
                return;

            (int _, int height) = Common.GetStringSize(txt);
            string[] txtSplit = txt.Split("\n");
            string[] boardCp = this._board;

            for (int y = 0; y < height; y++)
                for (int x = 0; x < txtSplit[y].Length; x++)
                {
                    if (txtSplit[y][x] != 'ç')
                        boardCp[y+y0] = boardCp[y+y0].Remove(x0 + x, 1).Insert(x0 + x, txtSplit[y][x].ToString());
                }

            this._board = boardCp;
        }

        /// <summary>Write a text at the given location letter by letter.</summary>
        /// <param name="txt">The text to display.</param>
        /// <param name="x">The x coordinate, with 0 being the left.</param>
        /// <param name="y">The y coordinate, with 0 being the top.</param>
        /// <param name="speed">The delay between each letter (in ms).</param>
        public void WriteWithEffect(string? txt, int x, int y, int speed) {
            if (txt == null) return;

            string[] list = txt.Split('\n');

            for (int yOffset = 0; yOffset < list.Length; yOffset++)
                for (int xOffset = 0; xOffset < list[yOffset].Length; xOffset++)
                {
                    Write(list[yOffset][xOffset].ToString(), x + xOffset, y + yOffset);
                    Thread.Sleep(speed);
                }
        }

        /// <summary>Write a string (at the given position), even if the string is outside of the screen</summary>
        /// <param name="txt">The string you want to display.</param>
        /// <param name="x0">The x location.</param>
        /// <param name="y0">The y location.</param>
        public void WriteWithoutBorder(string? txt, int x0, int y0) {
            if (txt != null) {

                string[] splited = txt.Split('\n');
                string[] boardCp = this._board;

                for (int y = 0; y < splited.Length; y++)
                {
                    if (y0 + y < 0 || y0 + y >= this._height)
                        continue;

                    for(int x = 0; x < splited[y].Length; x++)
                    {
                        if (x + x0 < 0 || x + x0 >= this._width)
                            continue;

                        boardCp[y+y0] = boardCp[y+y0].Remove(x0 + x, 1).Insert(x0 + x, splited[y][x].ToString());
                    }
                }

                this._board = boardCp;
            }
        }

        /// <summary>Write a string (at the given position), even if the string is outside of the screen with an alpha layer</summary>
        /// <param name="txt">The string you want to display.</param>
        /// <param name="x0">The x location.</param>
        /// <param name="y0">The y location.</param>
        public void WriteWithoutBorderWithAlpha(string? txt, int x0, int y0) {
            if (txt != null) {

                string[] splited = txt.Split('\n');
                string[] boardCp = this._board;

                for (int y = 0; y < splited.Length; y++)
                {
                    if (y0 + y < 0 || y0 + y >= this._height)
                        continue;

                    for(int x = 0; x < splited[y].Length; x++)
                    {
                        if (x + x0 < 0 || x + x0 >= this._width || splited[y][x] == 'ç')
                            continue;

                        boardCp[y+y0] = boardCp[y+y0].Remove(x0 + x, 1).Insert(x0 + x, splited[y][x].ToString());
                    }
                }

                this._board = boardCp;
            }
        }

        /// <summary>Display a text at the given location and wait for a key to continue the script's execution.</summary>
        /// <param name="x">The x coordinate, with 0 being the left.</param>
        /// <param name="y">The y coordinate, with 0 being the top.</param>
        /// <param name="txt">The text to display.</param>
        /// <param name="expectedKey">The Key that is expected to continue the script.</param>
        public void AskContinue(int x, int y, string txt, ConsoleKey expectedKey) {

            Write(txt, x, y);

            ConsoleKey key;

            do {
                key = Console.ReadKey(true).Key;
            } while(key != expectedKey);
        }

        /// <summary>Replace the given rectangle by a blank one.</summary>
        /// <param name="x">The x starting coordinate, with 0 being the left</param>
        /// <param name="y">The y starting coordinate, with 0 being the top</param>
        /// <param name="width">The width of the rectange</param>
        /// <param name="height">The height of the rectange</param>
        public void Erase(int x, int y, int width, int height) {
            if (width < 0 || height < 0 || x < 0 || y < 0) return;
            if (x + width > this._width) width = this._width-x;
            if (y + height > this._height) width = this._height-y;

            for (int heightCount = 0; heightCount < height; heightCount++) {
                Write(new String(' ', width), x, y+heightCount);
            }
        }

        /// <summary>Display a test screen on the whole Canavas filled with '#'.</summary>
        public void DisplayTestScreen()
        {
            Clear();
            for (int x = 0; x < this._width; x++)
            {
                for (int y = 0; y < this._height; y++)
                {
                    Console.SetCursorPosition(x, y);
                    if (x == 0 || x == this._width-1) Console.Write("|");
                    else if (y == 0 || y == this._height-1) Console.Write("-");
                    else Console.Write("#");
                }
            }

            Console.SetCursorPosition(this._defaultCursorLocation.x, this._defaultCursorLocation.y);
        }

        /// <summary>Display a string in the middle of the screen after clearing it.</summary>
        /// <param name="logo">The logo to display on the screen</param>
        public void DisplayLogo(string logo) {
            Clear();
            (int Width, int Height) logoSize = Common.GetStringSize(logo);
            Write(logo, (this._width - logoSize.Width) / 2, (this._height - logoSize.Height) / 2);
            Thread.Sleep(2000);
        }

        /// <summary>Edit a string by inserting a new string inside</summary>
        /// <param name="original">The original string</param>
        /// <param name="editPart">The string to insert</param>
        /// <param name="startIndex">The index where you want to insert the new string</param>
        /// <returns>The edited string</returns>
        public string EditString(string original, string editPart, int startIndex)
        {
            if (editPart.Length + startIndex >= original.Length)
                return original;

            return original.Remove(startIndex, editPart.Length).Insert(startIndex, editPart);
        }

        /// <summary>Display a rectangle with a centered text inside</summary>
        /// <param name="txt">The text to display inside the rectangle</param>
        /// <param name="x0">The x coordinate of the rectangle</param>
        /// <param name="y0">The y coordinate of the rectangle</param>
        /// <param name="width">The width of the rectangle</param>
        /// <param name="height">The height of the rectangle</param>
        public void DisplayRectangleWithText(string? txt, int x0, int y0, int width, int height)
        {
            if (txt is null)
                return;

            (int width, int height) txtSize = Common.GetStringSize(txt);
            string[] txtSplit = txt.Split("\n");
            string[] boardCp = this._board;

            // draw the rectangle
            boardCp[y0] = EditString(boardCp[y0], '┏' + new string('━', width-2) + '┓', x0);

            for (int y = 1; y < height-1; y++)
                boardCp[y0+y] = EditString(boardCp[y0+y], '┃' + new string(' ', width-2) + '┃', x0);

            boardCp[y0+height-1] = EditString(boardCp[y0+height-1], '┗' + new string('━', width-2) + '┛', x0);

            // draw the text inside
            int topMargin = (height-txtSize.height)/2;

            for (int y = 0; y < txtSize.height; y++)
            {
                int leftMargin = (width-txtSplit[y].Length)/2;
                boardCp[y+topMargin] = EditString(boardCp[y+topMargin], txtSplit[y], leftMargin+x0);
            }

            this._board = boardCp;
        }

        /// <summary>Redraw the entire canvas on the screen.</summary>
        public void Update() {
            string toWrite = String.Join("\n", this._board);
            Console.SetCursorPosition(0, 0);
            Console.Write(toWrite);
        }
    }
}
