using Newtonsoft.Json;

namespace ProjS2
{
    public class Config
    {
        string appDataPath { get; set; }

        public Config() {
            // this.appDataPath = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
            this.appDataPath = Environment.CurrentDirectory;
        }

        public T? GetConfig<T>(string ?path) {
            if (path == null) throw new ArgumentNullException(nameof(path));
            string fileStr = File.ReadAllText(
                Path.Combine(this.appDataPath, path)
            );
            return JsonConvert.DeserializeObject<T>(fileStr);
        }
    }

    // define classes for all configs files

    public class ConfigFile {
        public Paths? paths { get; set; }
        public Styles? styles { get; set; }
        public string[]? mapsName { get; set; }
        public CoordinateObject[]? defaultPlayerLocation { get; set; }
    }

    public class Paths {
        public string[]? mapsPreview { get; set; }
        public string[]? mapsTerrain { get; set; }
        public string[]? mapsHitboxTerrain { get; set; }
        public string[]? story { get; set; }
        public string[]? logos { get; set; }
        public string[]? tuto { get; set; }
        public string? loadedStage { get; set; }
        public string? resetStage { get; set; }
        public Images? images { get; set; }
    }

    public class Styles {
        public ButtonStyle? button { get; set; }
    }

    public class ButtonStyle {
        public int? width { get; set; }
        public int? height { get; set; }
    }

    public class Images {
        public string? menu { get; set; }
        public string? skeleton01 { get; set; }
        public string? skeleton01Interact { get; set; }
        public string? speech { get; set; }
        public string? speech01 { get; set; }
        public string? speech02 { get; set; }
        public string? littleGhost { get; set; }
        public string? heartFull { get; set; }
        public string? heartEmpty { get; set; }
        public string? podium { get; set; }
        public string? petdown { get; set; }
        public string? petleft { get; set; }
        public string? petright { get; set; }
        public string? petup { get; set; }
        public string? guard01 { get; set; }
        public string? secretDoor { get; set; }

        // skins
        public string? skinLeft { get; set; }
        public string? skinRight { get; set; }
        public string? skinDown { get; set; }
        public string? kingRight { get; set; }
        public string? kingLeft { get; set; }

        // items
        public string? itemCoinBig { get; set; }
        public string? itemCoinLittle { get; set; }
        public string? itemRustySwordBig { get; set; }
        public string? itemRustySwordLittle { get; set; }
        public string? itemHatBig { get; set; }
        public string? itemHatLittle { get; set; }
        public string? itemTabletBig { get; set; }
        public string? itemTabletLittle { get; set; }
    }

    public class CoordinateObject
    {
        public int y { get; set; }
        public int x { get; set; }
    }
}