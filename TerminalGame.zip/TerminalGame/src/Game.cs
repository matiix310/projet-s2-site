using ProjS2.RpgGame;
using ProjS2.TerminalGame;
using ProjS2.Utils;

namespace ProjS2
{

    public class Game {

        public bool IsGame;
        public List<string> Location;

        public bool TerminalState;
        public bool RpgState;
        private bool PauseState;
        private Canvas canvas;
        private PauseMenu pauseMenu;
        private ConfigFile? configFile;
        private Tree tree;
        private InputListener inputListener;
        private Menu _menu;
        private bool _first_launch = false;
        private SaveManager _saveManager;

        public string? DisplayedHint;
        public Terminal Terminal;
        public Rpg Rpg;
        public bool IsKing;

        public Game(InputListener inputListener, Canvas canvas, Menu menu) {
            this.configFile = FileManager.GetConfigFile();

            this.canvas = canvas;
            this._menu = menu;

            // define pause menu
            int? left = (canvas.GetWidth()-this.configFile?.styles?.button?.width)/2;

            PauseButton[] pauseButtons = new PauseButton[] {
                new PauseButton(
                    this.configFile?.styles?.button?.width,
                    this.configFile?.styles?.button?.height,
                    left,
                    5,
                    "resume",
                    this.canvas,
                    Resume),

                new PauseButton(
                    this.configFile?.styles?.button?.width,
                    this.configFile?.styles?.button?.height,
                    left,
                    15,
                    "dive",
                    this.canvas,
                    Dive),

                new PauseButton(
                    this.configFile?.styles?.button?.width,
                    this.configFile?.styles?.button?.height,
                    left,
                    25,
                    "exit and save",
                    this.canvas,
                    Stop),

                new PauseButton(
                    this.configFile?.styles?.button?.width,
                    this.configFile?.styles?.button?.height,
                    left,
                    35,
                    "reset the save",
                    this.canvas,
                    ResetSave),
            };

            this.pauseMenu = new PauseMenu(this.canvas, this, pauseButtons);

            this.inputListener = inputListener;

            this.Location = new List<string>();

            // Load the Save from the config file
            this._saveManager = new SaveManager(this.canvas, this);

            this.IsKing = this._saveManager.LoadedStage.isKing;

            this._first_launch = this._saveManager.LoadedStage.firstLaunch;

            // define Terminal
            this.Terminal = new Terminal(this.canvas, canvas.GetWidth(), canvas.GetHeight(), canvas.GetBufferWidth(), configFile, this.inputListener, this._saveManager, this);

            // define Rpg
            this.Rpg = new Rpg(this.canvas, canvas.GetWidth(), canvas.GetHeight(), canvas.GetBufferWidth(), configFile, this.inputListener, this._saveManager, this);
        }

        public void Stop() {

            // Save the game
            this._saveManager.Save();

            this.IsGame = false;
            this.TerminalState = false;
            this.RpgState = false;
            this.pauseMenu.Hide();
            this.PauseState = false;
            this._menu.SetCanvasUpdateState(true);
            this._menu.DisplayMenu();

            // Linux test
//            Console.SetWindowSize(Console.LargestWindowWidth, Console.LargestWindowHeight);
//            Console.SetBufferSize(Console.LargestWindowWidth, Console.LargestWindowHeight);
        }

        public void Start() {

            this.IsGame = true;

            if (this._first_launch)
            {
                // define Tuto
                Tuto tuto = new Tuto(this.canvas,this.configFile, this.inputListener, Start);
                tuto.Draw();
                this._first_launch = false;
            } else
            {
                // debug method call
                // this.canvas.DisplayTestScreen();

                // display logo
                Console.CursorVisible = false;
                int random = new Random().Next((int)this.configFile?.paths?.logos!.Length!);
                string logo = FileManager.GetFile(this.configFile?.paths?.logos![random]);
                this.canvas.DisplayLogo(logo);

                // intro
                string intro = FileManager.GetFile(this.configFile?.paths?.story![0]);
                (int x, int y) introPosition = (80, 10);
                this.canvas.Clear();
                this.canvas.WriteWithEffect(intro, introPosition.x, introPosition.y, 0);
                this.canvas.AskContinue(introPosition.x, introPosition.y + intro.Split('\n').Length + 1, "> To dive into the Termin@l press [SpaceBar]", ConsoleKey.Spacebar);

                // launch the game in the terminal state
                this.TerminalState = true;

                this.canvas.Clear();
                Resume();
            }

        }

        public void Resume() {
            if (this.PauseState)
            {
                this.pauseMenu.Hide();
                this.PauseState = false;
                this._menu.SetCanvasUpdateState(true);
            }

            // listen to escape input
            this.inputListener.ResetListenedKeys();
            this.inputListener.ListenToInput(ConsoleKey.Escape, Pause);
            this.inputListener.StartListening();

            if (this.TerminalState) this.Terminal.Draw();
            if (this.RpgState) this.Rpg.Draw();
        }

        public void Dive() {
            this.RpgState = !this.RpgState;
            this.TerminalState = !this.TerminalState;
            this.canvas.Clear();
            this.Resume();
        }

        public void SetPauseState(bool gamePause) {
            this.PauseState = gamePause;
            this._menu.SetCanvasUpdateState(false);
        }

        public bool GetPauseState() {
            return this.PauseState;
        }

        public void Pause() {
            this.PauseState = true;
            this._menu.SetCanvasUpdateState(false);

            // display pause screen
            this.canvas.Clear();
            this.inputListener.ResetListenedKeys();
            this.pauseMenu.Show();
        }

        public void ResetSave()
        {
            // save the reset stage
            LoadedStageUtils.Save(LoadedStageUtils.GetResetStage());

            this.IsGame = false;
            this.TerminalState = false;
            this.RpgState = false;
            this.pauseMenu.Hide();
            this.PauseState = false;
            this._menu.SetCanvasUpdateState(true);
            this._menu.DisplayMenu();
        }

        public void Update()
        {
            if (this.TerminalState) this.Terminal.Update();
            if (this.RpgState) this.Rpg.Update();
        }

        /// <summary>Display a rectangle with a centered text inside</summary>
        /// <param name="txt">The text to display inside the rectangle</param>
        /// <param name="time">The time to display the rectangle in ms</param>
        public void DisplayHint(string? txt, int time)
        {
            this.DisplayedHint = txt;
            Update();
            TimerManager.SetTimeout((_, _) =>
            {
                this.DisplayedHint = null;
                Update();
            }, time);
        }

        public int GetFps() => this._menu.Fps;
    }
}