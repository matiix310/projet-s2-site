using ProjS2.Utils;
using System;
using System.Collections.Generic;
using Timer = System.Timers.Timer;

namespace ProjS2.RpgGame
{
    public class Pet : Drawable
    {
        private ConfigFile _configFile;
        private Canvas _canvas;
        private Rpg _rpg;
        private int _x;
        private int _y;
        private string _label;
        private string _skin;
        private int _width;
        private int _height;
        private string[] _map;
        public List<(int, int)> _path; // chemin calculé par l'algorithme A*
        private (int? X, int? Y) _lastDestination;
        private Timer? _drawingInterval;
        private Timer? _followPlayer;

        public Pet(ConfigFile config, Canvas canvas, int x, int y, string label, string skin, Rpg rpg)
        {
            _configFile = config;
            _canvas = canvas;
            _x = x;
            _y = y;
            _label = label;
            _skin = skin;
            _height = canvas.GetHeight();
            _width = canvas.GetBufferWidth();
            _rpg = rpg;
            _path = new List<(int, int)>();
        }

        public void StartFollowing(Player player)
        {
            if (this._followPlayer is not null)
                this._followPlayer.Stop();

            this._followPlayer = TimerManager.SetInterval((_, _) =>
                {
                    MoveTo(player.pos.X, player.pos.Y, 30, player);
                }, 2000);
        }

        public void StopFollowing()
        {
            if (this._followPlayer is not null)
                this._followPlayer.Stop();
        }

        public override void Draw()
        {
            string[] skin = _skin.Split("\n");

            // récupère la position du joueur
            (int playerX, int playerY) = _rpg.GetPlayerPosition();

            // calcule le décalage du coin supérieur gauche par rapport à celui de l'écran
            int npcX = _x - playerX + _width / 2;
            int npcY = _y - playerY + _height / 2;

            string displayedSkin = "";

            // lignes du skin qui seront affichées à l'écran
            for (int y = Math.Max(0, npcY); y < Math.Min(npcY + skin.Length, _height); y++)
            {
                string line = "";
                // caractères de chaque ligne du skin qui seront affichés à l'écran
                for (int x = Math.Max(0, npcX); x < Math.Min(npcX + skin[y - npcY].Length, _width); x++)
                {
                    char c = skin[y - npcY][x - npcX];
                    line += c;
                }
                displayedSkin += line + (y == Math.Min(npcY + skin.Length - 1, _height - 1) ? "" : "\n");
            }

            _canvas.WriteWithAlpha(displayedSkin, Math.Max(0, npcX), Math.Max(0, npcY));
        }

        private bool CanMoveTo(int x, int y)
        {
            return _rpg.IsPosAvailible(x, y);
        }

        private void UpdateSkin(int moveX, int moveY)
        {
            if (moveY > 0 && moveX != 0)
                _skin = FileManager.GetFile(_configFile.paths?.images?.petdown);
            else if (moveY < 0)
                _skin = FileManager.GetFile(_configFile.paths?.images?.petup);
            else if (moveX < 0 && moveY == 0)
                _skin = FileManager.GetFile(_configFile.paths?.images?.petleft);
            else if (moveX > 0 && moveY == 0)
                _skin = FileManager.GetFile(_configFile.paths?.images?.petright);
        }

        private void CalculatePathTo(int destinationX, int destinationY)
        {
            // renitialiser le chemin précédent
            _path.Clear();

            // obtenir la position actuelle du pet
            (int startX, int startY) = (_x, _y);

            // vérifier si la position de départ et la position cible sont valides
            if (!CanMoveTo(startX, startY) || !CanMoveTo(destinationX, destinationY))
                return;

            // implémentation de l'algorithme A*
            PriorityQueue<(int, int), float> openSet = new PriorityQueue<(int, int), float>();
            Dictionary<(int, int), (int, int)> cameFrom = new Dictionary<(int, int), (int, int)>();
            Dictionary<(int, int), float> gScore = new Dictionary<(int, int), float>();

            openSet.Enqueue((startX, startY), 0);
            gScore[(startX, startY)] = 0;

            while (openSet.Count > 0)
            {
                (int xActuelle, int yActuelle) = openSet.Dequeue();

                if (xActuelle == destinationX && yActuelle == destinationY)
                    break;

                List<(int, int)> voisin = GetNeighbors(xActuelle, yActuelle);

                foreach ((int voisinX, int voisinY) in voisin)
                {
                    float gScoreTemp = gScore[(xActuelle, yActuelle)] + 1; // cou déplacer d'une case (suppose être 1)

                    if (!gScore.ContainsKey((voisinX, voisinY)) || gScoreTemp < gScore[(voisinX, voisinY)])
                    {
                        cameFrom[(voisinX, voisinY)] = (xActuelle, yActuelle);
                        gScore[(voisinX, voisinY)] = gScoreTemp;
                        float fScore = gScoreTemp + Heuristic(voisinX, voisinY, destinationX, destinationY);
                        openSet.Enqueue((voisinX, voisinY), fScore);
                    }
                }
            }

            // reconstruction du chemin
            if (cameFrom.ContainsKey((destinationX, destinationY)))
            {
                (int xActuelle, int yActuelle) = (destinationX, destinationY);
                while (xActuelle != startX || yActuelle != startY)
                {
                    _path.Insert(0, (xActuelle, yActuelle));
                    (xActuelle, yActuelle) = cameFrom[(xActuelle, yActuelle)];
                }
            }
        }

        private List<(int, int)> GetNeighbors(int x, int y)
        {
            List<(int, int)> voisin = new List<(int, int)>();

            // aouter les positions voisines valides (en haut en bas à gauche à droite)
            if (CanMoveTo(x, y - 1)) voisin.Add((x, y - 1));
            if (CanMoveTo(x, y + 1)) voisin.Add((x, y + 1));
            if (CanMoveTo(x - 1, y)) voisin.Add((x - 1, y));
            if (CanMoveTo(x + 1, y)) voisin.Add((x + 1, y));

            return voisin;
        }

        private float Heuristic(int startX, int startY, int destinatiionX, int destinationY)
        {
            // utilisation de la distance de manhattan comme heuristique
            return Math.Abs(destinatiionX - startX) + Math.Abs(destinationY - startY);
        }

        public override int GetHeight() => _height;

        public override int GetWidth() => _width;


        /// <summary>Move the pet to the given destination with a custom speed</summary>
        /// <param name="destinationX">The X coordinate of the destination</param>
        /// <param name="destinationY">The Y coordinate of the destination</param>
        /// <param name="speed">ms between two moves</param>
        /// <param name="player">The player that is followed by the pet</param>
        public void MoveTo(int destinationX, int destinationY, int speed, Player? player = null)
        {

            if ((destinationX, destinationY) == this._lastDestination)
                return;

            this._lastDestination = (destinationX, destinationY);

            // calculer le chemin vers la position cible
            CalculatePathTo(destinationX, destinationY);

            // deplacer le pet à interval contstant : speed
            if (this._drawingInterval is not null)
                this._drawingInterval.Stop();

            if (player is not null)
                if (player.GetDistanceFrom((this._x, this._y)) > 150)
                {
                    (this._x, this._y) = player.pos;
                    return;
                }

            int posIndex = 0;
            (int Width, int Height) skinSize = Common.GetStringSize(this._skin);
            this._drawingInterval = TimerManager.SetInterval((_, _) =>
                {
                    if (posIndex < this._path.Count)
                    {
                        (this._x, this._y) = this._path[posIndex];
                        posIndex += 1;
                        // mettre à jour le skin en fonction du déplacement
                        int moveX = destinationX - _x;
                        int moveY = destinationY - _y;
                        UpdateSkin(moveX, moveY);

                        // redraw the pet at the new coordinates
                        this._rpg.Update();

                        // stop moving if the player is in range
                        if (player is not null)
                            if (player.GetDistanceFrom((this._x + skinSize.Width/2, this._y + skinSize.Height/2)) < 15)
                                posIndex = this._path.Count;

                    } else
                    {
                        if (this._drawingInterval is not null)
                            this._drawingInterval.Stop();
                    }

                }, speed);
        }

        public void SetPos(int x, int y)
        {
            this._x = x;
            this._y = y;
        }
    }
}