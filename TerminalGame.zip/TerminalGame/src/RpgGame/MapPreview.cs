using ProjS2.Utils;

namespace ProjS2.RpgGame {

    public class MapPreview : Drawable {

        private readonly Canvas _canvas;
        private readonly int _width;
        private readonly int _height;
        private readonly int _nameHeight;
        private readonly string[] _previews;
        private readonly string[] _mapsName;

        private readonly Rpg _rpg;

        public MapPreview(Canvas canvas, int width, int height, int nameHeight, string[] previews, string[] mapsName, Rpg rpg) {
            this._canvas = canvas;
            this._width = width;
            this._height = height;
            this._nameHeight = nameHeight;
            this._mapsName = new string[mapsName.Length];
            this._previews = new string[previews.Length];
            this._rpg = rpg;

            for (int i = 0; i < previews.Length; i++) {
                this._previews[i] = GenerateMapString(previews[i]);
                this._mapsName[i] = GenerateNameString(mapsName[i]);
            }
        }

        public override void Draw() {
            _canvas.Write(this._previews[this._rpg.SelectedMap] + this._mapsName[this._rpg.SelectedMap], this._canvas.GetBufferWidth(), 0);
        }

        public override int GetHeight() => this._height;

        public override int GetWidth() => this._width;

        private string GenerateMapString(string background) {
            string[] completeBg = new string[this._height-1-this._nameHeight];
            string[] bg = background.Split("\n");

            // first line
            completeBg[0] = '╔' + new string('═', this._width-2) + "╗";

            for (int i = 1; i < (bg.Length < this._height-1-this._nameHeight ? bg.Length : this._height-1-this._nameHeight); i++) {
                if (bg[i].Length < this._width-1) completeBg[i] = "║" + bg[i] + new String(' ', this._width-2 - bg[i].Length) + "║";
                else completeBg[i] = "║" + bg[i].Substring(0, this._width-2) + "║";
            }

            for (int i = bg.Length; i < this._height-1-this._nameHeight; i++) {
                completeBg[i] = "║" + new String(' ', this._width-2) + "║";
            }

            return String.Join('\n', completeBg) + "\n╠" + new String('═', this._width-2) + "╣";
        }

        private string GenerateNameString(string name) {
            string output = "";

            for (int i = 0; i < this._nameHeight-1; i++) {
                // if it is in the center, write the map name
                if ((this._nameHeight)/2 - (this._nameHeight%2 == 0 ? 1 : 0) == i)
                {
                    int horizontalMargin = (this._width-2-name.Length)/2;
                    output += "\n║" + new String(' ', horizontalMargin) + name.ToUpper() + new String(' ', horizontalMargin) + ((this._width-name.Length)%2 == 0 ? "" : " ") + "║";
                }
                else output += "\n║" + new String(' ', this._width-2) + "║";
            }

            return output + "\n╠" + new String('═', this._width-2) + "╣";
        }
    }
}