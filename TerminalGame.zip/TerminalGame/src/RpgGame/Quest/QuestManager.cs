using ProjS2.Utils;

namespace ProjS2.RpgGame.Quest
{
    public class QuestManager
    {
        public List<QuestObject> QuestlList;
        private Canvas _canvas;
        private Rpg _rpg;

        public QuestManager(Canvas canvas, Rpg rpg)
        {
            QuestObject[] quests = QuestUtils.GetQuests(FileManager.GetConfigFile());
            QuestlList = new List<QuestObject>();

            foreach (QuestObject quest in quests)
                QuestlList.Add(quest);

            this._canvas = canvas;
            this._rpg = rpg;
        }

        public void RemoveQuest(QuestObject quest)
        {
            // Remove a quest
            QuestlList.Remove(quest);
        }

        // remove a quest with its id
        public void RemoveQuest(string id)
        {
            this.QuestlList.RemoveAll(quest => quest.id == id);
        }

        public void AddQuest(QuestObject quest)
        {
            //ajoute une quête
            QuestlList.Add(quest);
            this._rpg.Inventory.UpdateQuest();
        }

        public void AddQuest(string id, string name, string description, string questOwner, int successCondition, int progress = 0, string neededItem = "")
        {
            // créer la quête
            QuestObject quest = new QuestObject
            {
                id = id,
                name = name,
                progress = progress,
                description = description,
                questOwner = questOwner,
                successCondition = successCondition,
                neededItem = neededItem
            };

            //ajoute une quête
            QuestlList.Add(quest);
            this._rpg.Inventory.UpdateQuest();
        }

        public void AddProgress(QuestObject quest, int amount)
        {
            int index = this.QuestlList.IndexOf(quest);

            if (index == -1)
                return;


            // remove the completed quest
            if(quest.progress == quest.successCondition)
                RemoveQuest(quest);

            // or edit the quest progression
            else
                this.QuestlList[index].progress += amount;
        }

        public void SetProgress(QuestObject quest, int amount)
        {
            // set the quest progression

            int index = this.QuestlList.IndexOf(quest);

            if (index == -1)
                return;


            // remove the completed quest
            if(amount == 0)
                RemoveQuest(quest);

            // or edit the quest progression
            else
                this.QuestlList[index].progress = amount;
        }

        public string GetQuestRepresentation(QuestObject quest, int width, int horizontalMargin)
        {
            int innerwidth = width-2-2*horizontalMargin;
            int percent = (int) (((float) quest.progress / quest.successCondition) * (innerwidth-2));
            string score = quest.progress + "/" + quest.successCondition;

            return '┏' + new string('━', width-2) + "┓\n" +
                   '┃' + new string(' ', horizontalMargin) + quest.name + new string(' ', width - 2 - horizontalMargin - quest.name.Length) + "┃\n" +
                   '┃' + new string(' ', horizontalMargin) + quest.questOwner + new string(' ', innerwidth - quest.questOwner.Length - score.Length) + score + new string(' ', horizontalMargin) + "┃\n" +
                   '┃' + new string(' ', horizontalMargin) + '┃' + new string('#', percent) + new string(' ', innerwidth-2-percent) + '┃' + new string(' ', horizontalMargin) + "┃\n" +
                   '┗' + new string('━', width-2) + '┛';
        }

        public void DisplayQuest()
        {
            int topMargin = 1;
            int spacing = 1;
            int questHeight = 5;
            int questWidth = 50;
            int questHorizontalMargin = 3;

            for (int i = 0; i < this.QuestlList.Count; i++)
            {
                this._canvas.Write(
                    GetQuestRepresentation(this.QuestlList[i], questWidth, questHorizontalMargin), this._canvas.GetBufferWidth() - questWidth - 2, topMargin + i*(questHeight+spacing)
                    );
            }
        }

        public QuestObject? GetQuest(string id) => this.QuestlList.Find(qo => qo.id == id);

        public List<QuestObject> Filter(Predicate<QuestObject> predicate) => this.QuestlList.FindAll(predicate);
    }
}