﻿using ProjS2.Utils;

namespace ProjS2.RpgGame;

public class NPC : Drawable
{
    private Canvas _canvas;
    private Rpg _rpg;
    private string _skin;
    private int _width;
    private int _height;
    // All the dialogue the NPC can say
    private string[] _dialogues;
    // the function that is called when someone interact with the NPC
    private Func<int, int> _interact;
    private (int, int) _center;

    // The index of the dialogue the NPC should say
    public int State;
    public int X;
    public int Y;
    public string Id;
    public string Name;

    public NPC(Canvas canvas, int x, int y, string id, string name, string skin, Rpg rpg, string[] dialogues, Func<int, int> interact)
    {
        this._canvas = canvas;
        this.X = x;
        this.Y = y;
        this._skin = skin;
        this.Id = id;
        this.Name = name;
        this._rpg = rpg;
        this._dialogues = dialogues;
        this._interact = interact;

        (this._width, this._height) = Common.GetStringSize(skin);
        this.State = 0;
        this._center = (x + this._width/2, y + this._height/2);
    }

    private string BuildDialogue(string dialogue)
    {
        (int width, int height) = Common.GetStringSize(dialogue);
        string output = '┌' + new string('─', width) + "┐\n";

        string[] splitedDialogue = dialogue.Split('\n');

        foreach (string line in splitedDialogue)
            output += '│' + line + new string(' ', width - line.Length) + "│\n";

        output += '└' + new string('─', width) + '┘';

        return output;
    }

    public override void Draw()
    {
        string[] skin = _skin.Split("\n");

        // récupère la position du joueur
        (int playerX, int playerY) = _rpg.GetPlayerPosition();

        // calcule le décalage du coin supérieur gauche par rapport à celui de l'écran
        int npcX = this.X - playerX + this._canvas.GetBufferWidth() / 2;
        int npcY = this.Y - playerY + this._canvas.GetHeight() / 2;

        if (this.State >= 0 && this.State < this._dialogues.Length && IsUnderInteractZone())
        {
            string dialogue = BuildDialogue(this._dialogues[this.State]);
            (int dialogueWidth, int dialogueHeight) = Common.GetStringSize(dialogue);
            
            _canvas.WriteWithoutBorder(dialogue, npcX + this._width/2 - dialogueWidth/2, npcY-dialogueHeight-1);
        }

        _canvas.WriteWithoutBorderWithAlpha(this._skin, npcX, npcY);
    }

    public bool IsUnderInteractZone()
    {
        // position du joueur par rapport au NPC
        return this._rpg.GetPlayerRpg().GetDistanceFrom(this._center) < 26;
    }

    public override int GetHeight()
    {
        return _height;
    }

    public override int GetWidth()
    {
        return _width;
    }

    public void Interact()
    {
        this.State = this._interact(this.State);
        this._rpg.Update();
    }
}