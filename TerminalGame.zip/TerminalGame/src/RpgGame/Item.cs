﻿using ProjS2.Utils;

namespace ProjS2.RpgGame;

public class Item : NPC
{

    public int Quantity;
    public string Description;

    public Item(Canvas canvas, int x, int y, int quantity, string description, string name, string id, string smallSkin, string bigSkin, Rpg rpg)
        : base(canvas, x, y, id, name, smallSkin, rpg, new string[] {"[HIT SPACEBAR TO PICK UP]"}, state =>
        {
            rpg.Inventory.AddItem(id, name, description, 1);
            rpg.RemoveItem(id, x, y);
            rpg.Inventory.UpdateQuest();
            rpg.DrawUpdate = false;

            // display in full screen the item
            (int width, int height) = Common.GetStringSize(bigSkin);
            (int leftMargin, int topMargin) = (canvas.GetWidth()/2 - width/2, canvas.GetHeight()/2 - height/2);
            string txt = "You get 1x " + name + ".";
            canvas.Clear();
            canvas.Write(txt, canvas.GetWidth()/2 - txt.Length/2, topMargin - 4);
            canvas.Write(bigSkin, leftMargin, topMargin);
            TimerManager.SetTimeout((_, _) =>
            {
                rpg.DrawUpdate = true;
                rpg.Update();
            }, 1500);


            return state;
        })
    {
        this.Quantity = quantity;
        this.Description = description;
    }
}