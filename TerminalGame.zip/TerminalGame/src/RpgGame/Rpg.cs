using ProjS2.RpgGame.Quest;
using ProjS2.Utils;

namespace ProjS2.RpgGame;

public class Rpg : Drawable
{
    private readonly int _width;
    private readonly int _height;
    private readonly ConfigFile? _configFile;
    private readonly InputListener _inputListerner;
    private readonly Game _game;
    private readonly MapTerrain _mapTerrain;
    private readonly MapPreview _mapPreview;

    private readonly Player _player;
    private Canvas _canvas;
    private bool _firstLaunch = true;

    public SaveManager SaveManager;
    public Pet Pet;
    public QuestManager QuestManager;
    public Inventory Inventory;
    public List<List<NPC>> NPCs;
    public List<List<Item>> Items;
    public List<List<Display>> Displays;
    public bool DrawUpdate = true;
    public bool HasPet = false;

    // the selected map
    public int SelectedMap;

    public Rpg(Canvas canvas, int width, int height, int bufferWidth, ConfigFile? configFile, InputListener inputListener, SaveManager saveManager, Game game)
    {
        this._width = width;
        this._height = height;

        this._inputListerner = inputListener;
        this._game = game;
        this._canvas = canvas;
        this._configFile = configFile;
        this.SaveManager = saveManager;

        // load the map preview
        int mapHeight = 30;
        this._mapPreview = new MapPreview(canvas, width-bufferWidth, mapHeight, 4, GetMapsPreviewList(), this._configFile?.mapsName!, this);

        // load the questManager
        this.QuestManager = new QuestManager(canvas, this);

        // load the inventory
        this.Inventory = new Inventory(canvas, width-bufferWidth, height-mapHeight, this);

        // load the terrain
        this._mapTerrain = new MapTerrain(canvas, bufferWidth, height, GetMapsTerrainList(), GetMapsHitboxTerrainList(), this);

        // load the player
        this._player = new Player(canvas, 50, 72, this);

        // Pet
        this.Pet = new Pet(configFile!, canvas,80, 72, "Snake",
            FileManager.GetFile(configFile!.paths!.images!.petleft), this);

        saveManager.LoadRpgComponents(this, this.QuestManager);

        this.Displays = new List<List<Display>>();

        for (int i = 0; i < saveManager.MapCount; i++)
            this.Displays.Add(new List<Display>());

        LoadDisplays();
    }

    public override void Draw()
    {
        if (!this._game.RpgState || !this.DrawUpdate)
            return;

        // get the selected map
        string folderName = this._game.Location.Count == 0 ? "Forest" : this._game.Location.Last();
        this.SelectedMap = this._configFile!.mapsName.ToList().IndexOf(folderName);

        if (_firstLaunch)
        {
            string intro = FileManager.GetFile(this._configFile?.paths?.story![1]);
            (int x, int y) introPosition = (90, 20);
            this._canvas.Clear();
            this._canvas.WriteWithEffect(intro, introPosition.x, introPosition.y, 5);
            this._canvas.AskContinue(introPosition.x, introPosition.y + intro.Split('\n').Length + 1, "> To dive into the game press [SpaceBar] and enjoy it !", ConsoleKey.Spacebar);
            string logo = FileManager.GetFile(this._configFile!.paths!.story![2]);
            this._canvas.DisplayLogo(logo);
        }
        
        _canvas.Clear();
        _firstLaunch = false;

        // set the player and the pet location location to the default one
        this._player.SetPos(this._configFile.defaultPlayerLocation![this.SelectedMap].x, this._configFile.defaultPlayerLocation[this.SelectedMap].y);
        this.Pet.SetPos(this._configFile.defaultPlayerLocation![this.SelectedMap].x - 7, this._configFile.defaultPlayerLocation[this.SelectedMap].y + 1);


        // draw components
        this.Inventory.Draw();
        this._mapTerrain.Draw();
        this._player.Draw();
        if (this.HasPet)
            this.Pet.Draw();

        // draw the NPCs
        if (this.NPCs.Count - 1 >= this.SelectedMap)
            foreach (NPC npc in this.NPCs[this.SelectedMap])
                npc.Draw();

        // draw the dropped items
        if (this.Items.Count - 1 >= this.SelectedMap)
            foreach (Item item in this.Items[this.SelectedMap])
                item.Draw();

        // draw the displays
        if (this.Displays.Count - 1 >= this.SelectedMap)
            foreach (Display display in this.Displays[this.SelectedMap])
                display.Draw();

        this._mapPreview.Draw();
        this.QuestManager.DisplayQuest();
        this._canvas.DisplayRectangleWithText(this._game.DisplayedHint, 45, 0, 80, 7);
        // capture keys
        this._inputListerner.ResetListenedKeys();
        if (this.HasPet)
            this.Pet.StartFollowing(this._player);
        CaptureMove();
    }
    
    public void Update()
    {
        if (!this._game.RpgState || !this.DrawUpdate)
            return;

        // draw the map terrain
        this._mapTerrain.Draw();

        // draw the player
        this._player.Draw();
        // draw the pet
        if (HasPet)
            this.Pet.Draw();

        // Draw the NPCs
        if (this.NPCs.Count - 1 >= this.SelectedMap)
            foreach (NPC npc in this.NPCs[this.SelectedMap])
                npc.Draw();

        // Draw the dropped items
        if (this.Items.Count - 1 >= this.SelectedMap)
            foreach (Item item in this.Items[this.SelectedMap])
                item.Draw();

        // Draw the displays
        if (this.Displays.Count - 1 >= this.SelectedMap)
            foreach (Display display in this.Displays[this.SelectedMap])
                display.Draw();

        this.Inventory.Draw();
        this._mapPreview.Draw();
        this._canvas.DisplayRectangleWithText(this._game.DisplayedHint, 45, 0, 80, 7);
        this.QuestManager.DisplayQuest();
        
    }

    public override int GetHeight() => this._height;

    public override int GetWidth() => this._width;

    public string[] GetMapsPreviewList() {
        string[] paths = this._configFile?.paths?.mapsPreview!;
        string[] maps = new string[paths.Length];

        for (int i = 0; i < paths.Length; i++) {
            maps[i] = FileManager.GetFile(paths[i]);
        }

        return maps;
    }

    public string[] GetMapsTerrainList() {
        string[] paths = this._configFile?.paths?.mapsTerrain!;
        string[] maps = new string[paths.Length];

        for (int i = 0; i < paths.Length; i++) {
            maps[i] = FileManager.GetFile(paths[i]);
        }

        return maps;
    }

    public string[] GetMapsHitboxTerrainList() {
        string[] paths = this._configFile?.paths?.mapsHitboxTerrain!;
        string[] maps = new string[paths.Length];

        for (int i = 0; i < paths.Length; i++) {
            maps[i] = FileManager.GetFile(paths[i]);
        }

        return maps;
    }

    public (int X, int Y) GetPlayerPosition()
    {
        return this._player.pos;
    }

    public bool IsPosAvailible(int x, int y) => this._mapTerrain.IsPosAvailible(x, y);


    // input caption
    private void CaptureMove()
    {
        this._inputListerner.ListenToInput(ConsoleKey.Escape, this._game.Pause);

        // go down
        this._inputListerner.ListenToInput(ConsoleKey.DownArrow, () =>
        {
            this._player.Move((0, 1));
        });

        // go up
        this._inputListerner.ListenToInput(ConsoleKey.UpArrow, () =>
        {
            this._player.Move((0, -1));
        });

        // go left
        this._inputListerner.ListenToInput(ConsoleKey.LeftArrow, () =>
        {
            this._player.Move((-2, 0));
        });

        // go right
        this._inputListerner.ListenToInput(ConsoleKey.RightArrow, () =>
        {
                this._player.Move((2, 0));
        });

        // interact
        this._inputListerner.ListenToInput(ConsoleKey.Spacebar, Interact);
        
        this._inputListerner.ListenToInput(ConsoleKey.E, () =>
        {
            //item coin npc
            foreach (var tup in Pet._path)
            {
                Console.WriteLine(tup.Item1+" "+tup.Item2);
            }

        });
        this._inputListerner.StartListening();
    }

    public void RemoveItem(string id, int x, int y)
    {
        foreach (List<Item> items in this.Items)
            items.RemoveAll(i => i.Id == id && i.X == x && i.Y == y);
    }

    public Canvas GetCanvasRpg() => _canvas;
    public Player GetPlayerRpg() => _player;
    public QuestManager GetQuestManager() => this.QuestManager;

    public void Interact()
    {
        int i = 0;

        // intercat with NPC
        if (this.NPCs.Count - 1 >= this.SelectedMap)
            while (i < this.NPCs[this.SelectedMap].Count)
            {
                NPC npc = this.NPCs[this.SelectedMap][i];
                if (npc.IsUnderInteractZone())
                    npc.Interact();

                i++;
            }

        i = 0;

        // intercat with Dropped Items
        if (this.Items.Count - 1 >= this.SelectedMap)
            while (i < this.Items[this.SelectedMap].Count)
            {
                Item item = this.Items[this.SelectedMap][i];
                if (item.IsUnderInteractZone())
                    item.Interact();

                i++;
            }
    }

    private void LoadDisplays()
    {
        List<(string id, int x, int y, int mapIndex, string content)> displays = new List<(string id, int x, int y, int mapIndex, string content)>()
        {
            ("secret_display", 375, 14, 4, GetCustomFile(new List<string>() { "Outer_court", "Castle", "Secret", "MySecret" }).textContent),
            ("castle_main_entrance", 294, 199, 1, "This entrance is reserved for the residents and the authorized staff."),
            ("42", 205, 7, 1, "42"),
            ("dont_ask", 66, 7, 3, "Don't Ask..."),
        };

        foreach ((string id, int x, int y, int mapIndex, string content) in displays)
        {
            this.Displays[mapIndex].Add(new Display(this._canvas, x, y, id, this, content));
        }
    }

    public void DisplayHint(string? txt, int time) => this._game.DisplayHint(txt, time);

    // getter and setter for the IsKing attribut of Game
    public void SetIsKing(bool isKing) => this._game.IsKing = isKing;
    public bool GetIsKing() => this._game.IsKing;

    // get a customFile from the save
    public CustomFile GetCustomFile(List<string> location)
    {
        CustomFile file = this.SaveManager.LoadedStage.folders![0];

        foreach(string fileName in location)
            file = file.content.ToList().Find(cf => cf.name == fileName)!;

        return file;
    }
}