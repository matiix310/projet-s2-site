namespace ProjS2.RpgGame;

public class Display : NPC {
    public Display(Canvas canvas, int x, int y, string id, Rpg rpg, string content) :
        base(canvas, x, y, id, "display", "", rpg, new string[] { content }, state => state)
    {
    }
}