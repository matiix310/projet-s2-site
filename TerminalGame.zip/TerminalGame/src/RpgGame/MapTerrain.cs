using ProjS2.Utils;

namespace ProjS2.RpgGame;

public class MapTerrain : Drawable {

    private readonly int _width;
    private readonly int _height;
    private readonly Canvas _canvas;
    private readonly Rpg _rpg;
    private readonly string[] _terrains;
    private readonly string[] _hitboxTerrains;

    public MapTerrain(Canvas canvas, int width, int height, string[] terrains, string[] hitboxTerrains, Rpg rpg)
    {
        this._width = width;
        this._height = height;
        this._canvas = canvas;
        this._terrains = terrains;
        this._hitboxTerrains = hitboxTerrains;
        this._rpg = rpg;
    }

    public override void Draw()
    {
        // get the selected terrain
        string[] terrain = GetSelectedTerrain();

        // get the top left corner position
        (int X, int Y) topLeftPos = this._rpg.GetPlayerPosition();
        topLeftPos.X -= this._width/2;
        topLeftPos.Y -= this._height/2;

        string displayedTerrain = "";

        for (int y = topLeftPos.Y; y < topLeftPos.Y + this._height; y++)
        {
            string line = "";
            for (int x = topLeftPos.X; x < topLeftPos.X + this._width; x++)
            {
                if (y < 0 || y >= terrain.Length || x < 0 || x >= terrain[y].Length)
                    line += " ";

                else
                    line += terrain[y][x];
            }
            displayedTerrain += line + (y == topLeftPos.Y + this._height - 1 ? "" : "\n");
        }

        this._canvas.Write(displayedTerrain, 0, 0);
    }

    public override int GetHeight() => this._height;

    public override int GetWidth() => this._width;

    public string[] GetSelectedTerrain()
    {
        return this._terrains[this._rpg.SelectedMap].Split("\n");
    }

    public string[] GetSelectedHitboxTerrain()
    {
        return this._hitboxTerrains[this._rpg.SelectedMap].Split("\n");
    }

    public bool IsPosAvailible(int x, int y)
    {
        string[] terrain = GetSelectedHitboxTerrain();
        return y < 0 || y >= terrain.Length || x < 0 || x >= terrain[y].Length || terrain[y][x] == ' ';
    }
}