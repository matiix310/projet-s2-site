using ProjS2.Utils;

namespace ProjS2.RpgGame;

public class Inventory : Drawable {

    private readonly int _height;
    private readonly int _width;
    private readonly Canvas _canvas;
    private List<ItemObject> _items;
    private Rpg _rpg;

    public Inventory(Canvas canvas, int width, int height, Rpg rpg)
    {
        this._canvas = canvas;
        this._width = width;
        this._height = height;
        this._rpg = rpg;
        this._items = new List<ItemObject>();
    }

    public override void Draw()
    {
        int topMargin = 4;
        int spaceUnderTitle = 2; // without counting the space before each item
        string output = "";

        // generate top margin
        for (int i = 0; i < topMargin; i++)
            output += "║" + new String(' ', this._width-2) + "║\n";

        // write "Inventory:"
        int horizontalMargin = (this._width-12)/2;
        output += "║" + new String(' ', horizontalMargin) + "Inventory:" + new String(' ', horizontalMargin) + ((this._width-12)%2 == 0 ? "" : " ") + "║\n";

        // place spaces under the title
        for (int i = 0; i < spaceUnderTitle; i++)
            output += "║" + new String(' ', this._width-2) + "║\n";

        // display the content
        foreach (ItemObject item in this._items)
            output += "║" + new String(' ', this._width-2) + "║\n║" + new String(' ', 7) + item.quantity + "x   " + item.name + new String(' ', this._width - 13 - item.quantity.ToString().Length - item.name.Length) + "║\n";

        // fill with spaces the remaining space
        for (int i = 0; i < this._height - topMargin - 1 - spaceUnderTitle - this._items.Count*2 - 1; i++)
            output += "║" + new String(' ', this._width-2) + "║\n";

        // last line without "\n"
        output += "╚" + new String('═', this._width-2) + "╝";

        this._canvas.Write(output, this._canvas.GetBufferWidth(), this._canvas.GetHeight()-this._height);
    }

    public override int GetHeight() => this._height;

    public override int GetWidth() => this._width;

    public void AddItem(string id, string name, string description, int quantity)
    {
        if (_items.Any(s => s.name == name))
        {
            var index = _items.ToList().IndexOf(_items.First(s => s.name == name));
            _items[index].quantity++;

            if (this._items[index].quantity == 0)
                this._items.RemoveAt(index);
        }
        else
        {
            var newItem = new ItemObject();
            newItem.id = id;
            newItem.quantity = quantity;
            newItem.description = description;
            newItem.name = name;
            this._items.Add(newItem);
        }

        UpdateQuest();
    }

    public bool RemoveItem(string id, int quantity)
    {
        for (int i = 0; i < this._items.Count; i++)
        {
            ItemObject itemObject = this._items[i];
            if (itemObject.id == id)
            {
                // remove the item
                if (itemObject.quantity == quantity)
                {
                    this._items.Remove(itemObject);
                    return true;

                }

                if (itemObject.quantity > quantity)
                {
                    itemObject.quantity -= quantity;
                    return true;
                }
            }

            UpdateQuest();
        }

        return false;
    }

    public ItemObject? GetItem(string id)
    {
        return this._items.Find(itemObject => itemObject.id == id);
    }

    public void UpdateQuest()
    {
        foreach (ItemObject item in this._items)
        {
            List<QuestObject> quests = this._rpg.GetQuestManager().Filter(qo => qo.neededItem == item.id);
            foreach(QuestObject quest in quests)
                this._rpg.GetQuestManager().SetProgress(quest, Math.Min(item.quantity, quest.successCondition));
        }

        if (this._items.Find(item => item.id == "tablet") is not null)
        {
            // unlock the tablet file
            this._rpg.SaveManager.EditCustomFileStateAndVisibility(new List<string>() { "Outer_court", "Castle", "Tablet.py" }, "unlocked", true);
        }
    }
    
    public List<ItemObject> GetItems() => this._items;
}