using ProjS2.Utils;

namespace ProjS2.RpgGame;

public class Player : Drawable {

    private readonly Canvas _canvas;
    private readonly Rpg _rpg;
    private string _playerSkin;
    private string[] _playerSkins;

    public (int X, int Y) pos {get; private set;}

    public Player(Canvas canvas, int x0, int y0, Rpg rpg)
    {
        this._canvas = canvas;
        this.pos = (x0, y0);
        this._rpg = rpg;
        UpdateSkin();
        this._playerSkin = this._playerSkins![0];
    }

    public void UpdateSkin()
    {
        // set the king skin
        if (this._rpg.GetIsKing())
            this._playerSkins = new string[]
            {
                FileManager.GetFile(FileManager.GetConfigFile().paths!.images!.kingLeft),
                FileManager.GetFile(FileManager.GetConfigFile().paths!.images!.kingRight),
                FileManager.GetFile(FileManager.GetConfigFile().paths!.images!.skinDown)
            };

        // set the ghost king
        else
            this._playerSkins = new string[]
            {
                FileManager.GetFile(FileManager.GetConfigFile().paths!.images!.skinLeft),
                FileManager.GetFile(FileManager.GetConfigFile().paths!.images!.skinRight),
                FileManager.GetFile(FileManager.GetConfigFile().paths!.images!.skinDown)
            };

        this._playerSkin = this._playerSkins[0];
    }

    public override void Draw()
    {
        // get screen size
        int width = this._canvas.GetBufferWidth();
        int height = this._canvas.GetHeight();

        this._canvas.WriteWithAlpha(this._playerSkin, width/2, height/2);
    }

    public bool Move((int X, int Y) vect)
    {
        // change the lpayer skin
        // left or top
        if (vect.X < 0 || vect.Y < 0)
            this._playerSkin = this._playerSkins[0];
        // right
        else if (vect.X > 0)
            this._playerSkin = this._playerSkins[1];
        // bottom
        else
            this._playerSkin = this._playerSkins[2];

        // check if the destination is availible
        (int X, int Y) dest = (this.pos.X + vect.X, this.pos.Y + vect.Y);
        (int Width, int Height) hitbox = Common.GetStringSize(this._playerSkin);

        for (int x = 0; x < hitbox.Width; x++)
            if (!this._rpg.IsPosAvailible(dest.X + x, dest.Y + hitbox.Height-1))
            {
                if (vect.X == 2 || vect.X == -2)
                    return Move((vect.X/2, 0));

                return false;
            };

        // move the player
        this.pos = dest;

        this._rpg.Update();

        return true;
    }

    public override int GetHeight() => Common.GetStringSize(this._playerSkin).Height;

    public override int GetWidth() => Common.GetStringSize(this._playerSkin).Width;

    public void SetSkin(string skin) => this._playerSkin = skin;
    public string GetSkin() => _playerSkin;

    public int GetDistanceFrom((int X, int Y) destination)
    {
        (int Width, int Height) skinSize = Common.GetStringSize(this._playerSkin);
        (int X, int Y) origin = (this.pos.X + skinSize.Width/2, this.pos.Y + skinSize.Height/2);
        int xDelta = origin.X - destination.X;
            int yDelta = (origin.Y - destination.Y)*2;

        return (int) Math.Sqrt(xDelta*xDelta + yDelta*yDelta);
    }

    public void SetPos(int x, int y)
    {
        this.pos = (x, y);
    }
}