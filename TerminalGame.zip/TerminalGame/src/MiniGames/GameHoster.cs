using System.Net;
using ProjS2.MiniGames.Tcp.Server;
using ProjS2.Utils;

namespace ProjS2.MiniGames;

public class GameHoster {
    
    private readonly Canvas _canvas;
    private readonly InputListener _inputListener;
    private readonly MiniGamesGameClient _gameClient;
    private readonly string? _pseudo;
    private readonly MiniGamesMenu _miniGamesMenu;
    public List<string?> PlayersPseudo;

    private Server? _server;
    private MiniGamesGameServer? _gameServer;
    
    private bool _gameStarted;

    public GameHoster(Canvas canvas, InputListener inputListener, MiniGamesMenu miniGamesMenu, MiniGamesGameClient game, string? pseudo)
    {
        this._canvas = canvas;
        this._inputListener = inputListener;
        this._miniGamesMenu = miniGamesMenu;
        this._gameClient = game;
        this._pseudo = pseudo;
        this.PlayersPseudo = new List<string?>();
        this._gameStarted = false;
        AddPlayer(pseudo);
    }
    
    public void Display()
    {
        CaptureInput();
        StartServer();
        Draw();
    }

    private void CaptureInput()
    {
        this._inputListener.ResetListenedKeys();
        this._inputListener.ListenToInput(ConsoleKey.Spacebar, Launch);
        this._inputListener.ListenToInput(ConsoleKey.Escape, () =>
        {
            if (this._server != null)
                this._server.StopListening();
            this._miniGamesMenu.Start(this._pseudo);
        });
        this._inputListener.StartListening();
    }

    public void Draw()
    {
        if (this._gameStarted)
            return;

        // draw the blank table in the center (width)
        int tableWidth = 70;
        this._canvas.Write(GenerateTable(this._gameClient.MaxPlayer, tableWidth), (this._canvas.GetWidth()-tableWidth)/2, 5);

        // print the local ip
        string localIp = GetLocalIp();
        this._canvas.Write(localIp, (this._canvas.GetWidth()-localIp.Length)/2, this._canvas.GetHeight()-11);

        // draw the launch button
        (int Width, int Height) buttonSize = (30, 5);
        int spaceBetween = 30;

        this._canvas.Write(
        Common.GenerateButton("[SpaceBar] : Start", buttonSize.Width, buttonSize.Height),
            (this._canvas.GetWidth() - spaceBetween)/2 - buttonSize.Width,
            this._canvas.GetHeight()-7
        );

        this._canvas.Write(
            Common.GenerateButton("[Escape] : Exit", buttonSize.Width, buttonSize.Height),
            (this._canvas.GetWidth() + spaceBetween)/2,
            this._canvas.GetHeight()-7
        );
    }
    
    private string GenerateTable(int rowCount, int tableWidth)
    {
        string table = "";
        for (int i = 0; i < rowCount; i++)
        {
            if (i == 0)
                table += '╭' + new string('─', tableWidth-2) + "╮\n";
            else
                table += '├' + new string('─', tableWidth-2) + "┤\n";
            
            for (int j = 0; j < 3; j++)
            {
                if (j == 1 && i < this.PlayersPseudo.Count)
                {
                    int margin = tableWidth-2 - this.PlayersPseudo[i].Length;
                    table += '│' + new String(' ', margin/2) + this.PlayersPseudo[i] + new String(' ', margin/2 + margin%2) + "│\n";
                }
                else
                    table += '│' + new String(' ', tableWidth-2) + "│\n";;
            }
        }
        table += '╰' + new string('─', tableWidth-2) + '╯';
        
        return table;
    }

    private string GetLocalIp()
    {
        if (!System.Net.NetworkInformation.NetworkInterface.GetIsNetworkAvailable())
            return "No connection !";

        string hostName = Dns.GetHostName();
        List<string> ips = new List<string>();

        foreach (IPAddress ip in Dns.GetHostEntry(hostName).AddressList)
            ips.Add(ip.ToString());

        return (ips.Count > 1 ? "Your IP addresses: " : "Your IP address: ") + String.Join(", ", ips);
    }

    private void Launch()
    {
        // check for minimum player
        if (this._gameClient.MinPlayer > this.PlayersPseudo.Count) return;

        // define the server
        this._gameServer = this._gameClient.GetServer(this.PlayersPseudo);

        // launch the game client and the server
        this._gameClient.Start(this.PlayersPseudo, this._gameServer.ReceiveMessage, this._pseudo, () => {}, () =>
        {
            this._canvas.Clear();
            this._gameStarted = false;
            CaptureInput();
            Draw();
        });
        this._server.SendMessageToEveryClients("startGame:_");
        this._gameServer.Start(this._server);
        this._gameStarted = true;
    }

    private void AddPlayer(string? pseudo)
    {
        this.PlayersPseudo.Add(pseudo);
    }

    private void RemovePlayer(string? pseudo)
    {
        this.PlayersPseudo.Remove(pseudo);
    }

    private void StartServer()
    {
        // server
        this._server = new Server(1001, this._gameClient.MaxPlayer-1, this._gameClient.ReceiveMessage);
        Thread serverThread = new Thread(_server.StartListening);

        // OnMessageReceived
        _server.AddEventListener("OnMessageReceived", (_, e) =>
        {
            if (this._gameServer is not null)
                this._gameServer.ReceiveMessage(e.GetInfo());
        });

        _server.AddEventListener("OnPlayerConnect", (_, e) =>
        {
            AddPlayer(e.GetId());
            Draw();

            TimerManager.SetTimeout((_, _) =>
            {
                this._server.BroadcastMessage("setPlayers:" + String.Join(',', this.PlayersPseudo));
                this._server.SendMessage(e.GetId(), "setGame:" + this._gameClient.Id);
            }, 100);
        });

        _server.AddEventListener("OnPlayerDisconnect", (_, e) =>
        {
            RemovePlayer(e.GetId());
            this._server.BroadcastMessage("setPlayers:" + String.Join(',', this.PlayersPseudo));
            Draw();
        });

        //        serverThread.IsBackground = true;
        serverThread.Start();
    }
}