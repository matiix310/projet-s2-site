using ProjS2.MiniGames.Tcp.Server;
using ProjS2.Utils;
using Timer = System.Timers.Timer;

namespace ProjS2.MiniGames.Games.GhostDash;

public class GhostDashClient : MiniGamesGameClient {
    
    private static Dictionary<string, (string representation, int spaceBottom)> _obstacles = new Dictionary<string, (string representation, int spaceBottom)>()
    {
        {"spike", ("▲", 0)},
        {"block2", ("▲\n▉", 0)}
    };

    private string _skin;
    private (int Width, int Height) _skinSize;
    private (int X, int Y) _position;
    private int _spacing = 13;
    private int _x;
    private System.Timers.Timer? _interval;
    private List<(string Name, int Position)>? _placedObstacles;

    private bool _isFalling;
    private bool _lockFalling;

    private string _heartFull;
    private string _heartEmpty;
    private (int Width, int Height) _heartSize;
    private int _lifeCount;
    private int _distance;
    private int _groundPosition;
    private int _minInterval;
    private int _maxInterval;
    private string? _pseudo;
    
    private bool _gameIsRuning = true;
    private Timer? _gravity;

    private Action<string>? _sendToServer;
    
    private Dictionary<string, (int LifeCount, int Distance, string Pseudo)>? _playersData;
    private Dictionary<string, int>? _playerPositions;

    private Action? _endTheGame;
    private Action? _disposeClient;

    public GhostDashClient(Canvas canvas, InputListener inputListener) : base(canvas, inputListener, "GhostDash", "Ghost Dash", "Un jeu de course linéaire ou le but est d'aller le plus loin possible.", 3, 1)
    {

        // get the skin
        ConfigFile configFile = FileManager.GetConfigFile();
        this._skin = FileManager.GetFile(configFile.paths!.images!.littleGhost);

        // get the hearts
        this._heartFull = FileManager.GetFile(configFile.paths!.images!.heartFull);
        this._heartEmpty = FileManager.GetFile(configFile.paths!.images!.heartEmpty);

        // set the propertiesStart
        this._skinSize = Common.GetStringSize(this._skin);
        this._heartSize = Common.GetStringSize(this._heartFull);
        this._groundPosition = 3;
        this._minInterval = 10;
        this._maxInterval = 80;
    }

    public override void Start(List<string?> playersPseudo, Action<string>? sendToServer, string? pseudo, Action disposeClient, Action endTheGame)
    {
        // set default attributes
        this._placedObstacles = new List<(string obstacleName, int coordinate)>();
        this._placedObstacles.Add(("spike", this.Canvas.GetWidth()-3));
        this._isFalling = true;
        this._lockFalling = false;
        this._lifeCount = 3;
        this._distance = 0;
        this._gameIsRuning = true;
        this._x = this._maxInterval;
        this._playersData = new Dictionary<string,(int LifeCount, int Distance, string Pseudo)>();
        this._playerPositions = new Dictionary<string, int>();

        // set the default position
        // origin = bottom left
        this._position = (40, this.Canvas.GetHeight()-this._groundPosition-10);

        this._pseudo = pseudo;
        this._sendToServer = sendToServer;
        this.InputListener.ResetListenedKeys();
        this._disposeClient = disposeClient;
        this._endTheGame = endTheGame;

        this.Canvas.Clear();

        // capture moves
        this.InputListener.ListenToInput(ConsoleKey.Spacebar, Jump);

        this.InputListener.StartListening();

        // start the gravity
        this._gravity = TimerManager.SetInterval((_, _) =>
            {
                if (this._lockFalling) return;

                int yPos = this._position.Y + this._skinSize.Height-1;
                if (yPos < this.Canvas.GetHeight()-1 && !CheckForGround())
                {
                    this._isFalling = true;
                    this._position.Y += 1;

                } else
                {
                    this._isFalling = false;
                }

                this._sendToServer("setPos:" + this._pseudo + "," + this._position.Y);

            }, 150);

        Draw();
        Update();
    }

    private bool CheckForGround()
    {
        for (int x = 0; x < this._skinSize.Width; x++)
            if (this.Canvas.GetBoard()[this._position.Y + this._skinSize.Height][this._position.X + x] != ' ' && this.Canvas.GetBoard()[this._position.Y + this._skinSize.Height][this._position.X + x] != '▲')
                return true;

        return false;
    }

    private void Update()
    {
        if (!this._gameIsRuning) return;

        if (this._interval is not null)
            this._interval.Stop();

        this._interval = TimerManager.SetInterval((_, e) =>
        {
            if (!this._gameIsRuning) return;

            if (this._lifeCount == 0)
                this._gravity.Stop();

            UpdateObstacles();
            Draw();
            this._distance += 1;
            int percentage = 100 - (int) ((float)(this._x-this._minInterval)/(this._maxInterval-this._minInterval)*100);
            this.Canvas.Write("Vitesse : " + percentage + "%  ", 5, 3);
            this.Canvas.Write("Distance : " + _distance + "m", 5, 5);
        }, this._x);

        TimerManager.SetTimeout((_, e) =>
        {
            if (this._x > this._minInterval)
                this._x -= 1;
            Update();
        }, 2000);
    }

    public void UpdateObstacles()
    {
        // update all obstacle positions
        for (int i = 0; i < this._placedObstacles.Count; i++)
            this._placedObstacles[i] = (this._placedObstacles[i].Name, this._placedObstacles[i].Position-1);

        if (this._placedObstacles.Count > 0 && this._placedObstacles[0].Position < 0)
            this._placedObstacles.RemoveAt(0);

        // check for obstacle in collision with the player
        if (this._lifeCount != 0 && IsPlayerInCollisionWithObstacles())
        {
            this._lifeCount -= 1;
            this._sendToServer("updatePlayerData:" + this._lifeCount + ',' + this._distance + ',' + this._pseudo);
        }
    }

    private bool IsPlayerInCollisionWithObstacles()
    {
        foreach ((string Name, int Position) obstacle in this._placedObstacles)
        {
            if (IsPlayerInCollisionWithObstacle(obstacle))
            {
                this._placedObstacles.Remove(obstacle);
                return true;
            }
        }

        return false;
    }

    private bool IsPlayerInCollisionWithObstacle((string Name, int Position) obstacle)
    {
        // check for each pixel of the obstacle if it touches the player
        (int Width, int Height) obstacleSize = Common.GetStringSize(_obstacles[obstacle.Name].representation);
        for (int x = obstacle.Position; x < obstacle.Position + obstacleSize.Width; x++)
            for (int y = this.Canvas.GetHeight()-1-this._groundPosition-obstacleSize.Height; y < this.Canvas.GetHeight()-1-this._groundPosition; y++)
                if (x >= this._position.X && x < this._position.X + this._skinSize.Width && y >= this._position.Y && y < this._position.Y + this._skinSize.Height)
                    return true;

        return false;
    }

    private void Draw()
    {
        if (this._lifeCount > 0)
            // clear the old character canvas (on top of the actual)
            this.Canvas.Erase(this._position.X, this._position.Y-2, this._skinSize.Width, 2);

        // same for the opponents
        {
            int i = 1;
            foreach ((int LifeCount, int __, string Pseudo) playerData in this._playersData.Values)
            {
                if (playerData.Pseudo == this._pseudo) continue;
                if (playerData.LifeCount > 0)
                    this.Canvas.Erase(this._position.X, this._playerPositions[playerData.Pseudo]-2-this._spacing*i, this._skinSize.Width, 2);
                i += 1;
            }
        }


        // draw the terrain
        // clear the old terrain
        string terrain = "";
        for (int i = 0; i < 8; i++)
            terrain += new string(' ', this.Canvas.GetWidth()) + "\n";

        terrain += new string('▉', this.Canvas.GetWidth());
        if (this._lifeCount > 0)
            this.Canvas.Write(terrain, 0, this.Canvas.GetHeight()-9-this._groundPosition);

        // draw for the obstacles for the opponents
        {
            int i = 1;
            foreach ((int LifeCount, int Distance, string Pseudo ) playerData in this._playersData.Values)
            {
                if (playerData.Pseudo == this._pseudo) continue;

                if (playerData.LifeCount > 0)
                    this.Canvas.Write(terrain, 0, this.Canvas.GetHeight()-9-this._groundPosition-this._spacing*i);

                i += 1;
            }
        }

        // draw the obstacles
        foreach ((string Name, int Position) obstacle in this._placedObstacles)
        {
            if (this._lifeCount > 0)
                this.Canvas.Write(_obstacles[obstacle.Name].representation, obstacle.Position, this.Canvas.GetHeight()-1-Common.GetStringSize(_obstacles[obstacle.Name].representation).Height-this._groundPosition);

            // draw for the obstacles for the opponents
            int i = 1;
            foreach ((int LifeCount, int Distance, string Pseudo ) playerData in this._playersData.Values)
            {
                if (playerData.Pseudo == this._pseudo) continue;

                if (playerData.LifeCount > 0)
                    this.Canvas.Write(_obstacles[obstacle.Name].representation, obstacle.Position, this.Canvas.GetHeight()-1-Common.GetStringSize(_obstacles[obstacle.Name].representation).Height-this._groundPosition-this._spacing*i);

                i += 1;
            }
        }

        // draw the player
        this.Canvas.Write(this._lifeCount > 0 ? this._skin : this._skin.Replace('o', 'x'), this._position.X, this._position.Y);

        // same for the opponent
        {
            int i = 1;
            foreach ((int LifeCount, int Distance, string Pseudo ) playerData in this._playersData.Values)
            {
                if (playerData.Pseudo == this._pseudo) continue;

                this.Canvas.Write(playerData.LifeCount > 0 ? this._skin : this._skin.Replace('o', 'x'), this._position.X, this._playerPositions[playerData.Pseudo]-this._spacing*i);

                i += 1;
            }
        }


        // draw the hearts
        for (int i = 0; i < 3; i++)
        {
            this.Canvas.Write(this._lifeCount > i ? this._heartFull : this._heartEmpty, this.Canvas.GetWidth()-3*(this._heartSize.Width+1) + i*(this._heartSize.Width+1), 2);
        }
        
        // draw other players heart
        (int X, int Y) startPlayersLifePosition = (this.Canvas.GetWidth()-60, 15);
        int playerCount = 0;
        foreach ((int LifeCount, int Distance, string Pseudo) player in this._playersData.Values)
        {
            if (this._pseudo == player.Pseudo) continue;
            this.Canvas.Write(player.Pseudo + " : " + Common.Repeat("♦ ", player.LifeCount) + Common.Repeat("♢ ", 3 - player.LifeCount), startPlayersLifePosition.X, startPlayersLifePosition.Y + playerCount);
            playerCount += 2;
        }
    }

    private void Jump()
    {
        if (!this._isFalling)
        {
            this._position.Y -= 5;
            this._isFalling = true;
            this._lockFalling = true;

            TimerManager.SetTimeout((_, _) =>
            {
                this._lockFalling = false;
            }, 200);
        }
    }

    public override void ReceiveMessage(string message)
    {
        if (!message.Contains(":")) return;

        string action = message.Split(":")[0];
        string data = message.Split(":")[1];

        switch(action)
        {
            case "ranking" :
                this._gameIsRuning = false;
                this._lifeCount = 0;
                DisplayRanking(data);
                break;
                
            case "placeObstacle" :
                string[] obstacle = data.Split(',');
                this._placedObstacles.Add((obstacle[0], Int32.Parse(obstacle[1])));
                break;
                
            case "updatePlayersData" :
                ParsePlayerData(data);
                break;

            case "setPos" :
                int opponentPosition;
                if (Int32.TryParse(data.Split(',')[1], out opponentPosition))
                    this._playerPositions[data.Split(',')[0]] = opponentPosition;
                break;
        }
    }

    // parse the player data : <Distance>,<Pseudo>,<LifeCount>,<distance>,<Pseudo>, ...
    private void ParsePlayerData(string data)
    {
        // set the life of the player to the dictionary
        string[] playersData = data.Split(',');
        Dictionary<string, (int LifeCount, int Distance, string Pseudo)>? tempPlayerData = new Dictionary<string,(int LifeCount, int Distance, string Pseudo)>();

        // LifeCount,Distance,Pseudo,LifeCount,Distance,...
        for (int i = 0; i < playersData.Length; i += 3)
            tempPlayerData.Add(playersData[i+2], (Int32.Parse(playersData[i]), Int32.Parse(playersData[i+1]), playersData[i+2]));

        this._playersData = tempPlayerData;
    }
    
    public void DisplayRanking(string data)
    {
        this._interval!.Stop();

        // leave the room to prevent AFK
        this._disposeClient!();
        this.Canvas.Clear();

        ConfigFile configFile = FileManager.GetConfigFile();
        string podium = FileManager.GetFile(configFile.paths!.images!.podium);
        (int Width, int Height) podiumSize = Common.GetStringSize(podium);
        (int X, int Y) podiumPosition = ((this.Canvas.GetWidth() - podiumSize.Width)/2, (this.Canvas.GetHeight() - podiumSize.Height)/2);
        int podiumPlaceWidth = 10;

        this.Canvas.Write(FileManager.GetFile(configFile.paths.images.podium), podiumPosition.X, podiumPosition.Y);

        // compute the players position
        // origin is the bottom left of the podium place
        (int X, int Y)[] playerPodiumPosition = new (int X, int Y)[]
        {
            // 1st
            (podiumPosition.X + 10, podiumPosition.Y + 5),
            // 2nd
            (podiumPosition.X, podiumPosition.Y + 7),
            // 3rd
            (podiumPosition.X + 20, podiumPosition.Y + 9)
        };

        // place the players and their pseudo
        string[] splittedData = data.Split(',');
        for (int i = 0; i < splittedData.Length; i += 3)
        {
            // parse the data
            // <Rank>,<Distance>,<Pseudo>
            (int rank, int distance, string pseudo) = (Int32.Parse(splittedData[i]), Int32.Parse(splittedData[i+1]), splittedData[i+2]);

            // print the skin on the podium at the correct place
            this.Canvas.Write(this._skin, playerPodiumPosition[rank].X + 2, playerPodiumPosition[rank].Y - this._skinSize.Height);

            // print the pseudo on top of their ghost
            // trim the pseudo to fit in the place
            if (pseudo.Length > podiumPlaceWidth)
                pseudo = pseudo.Substring(0, podiumPlaceWidth);

            this.Canvas.Write(pseudo, playerPodiumPosition[rank].X + podiumPlaceWidth/2 - pseudo.Length/2, playerPodiumPosition[rank].Y - this._skinSize.Height - 2);

            // print the distance
            string distanceStr = distance + "m";
            this.Canvas.Write(distanceStr, playerPodiumPosition[rank].X + podiumPlaceWidth/2 - distanceStr.Length/2, playerPodiumPosition[rank].Y - this._skinSize.Height - 3);

            // draw the leave button at the center of the screen
            (int Width, int Height) buttonSize = (30, 5);
             this.Canvas.Write(
                Common.GenerateButton("[Spacebar] : Skip", buttonSize.Width, buttonSize.Height),
                (this.Canvas.GetWidth() - buttonSize.Width)/2,
                this.Canvas.GetHeight()-7
             );

             // listen to the spacebar input to go back to the lobby menu
             this.InputListener.ResetListenedKeys();
             this.InputListener.ListenToInput(ConsoleKey.Spacebar, () =>
             {
                 this._endTheGame();
             });
             this.InputListener.StartListening();
        }
    }
    
    public override MiniGamesGameServer GetServer(List<string?> playersPseudo)
    {
        return new GhostDashServer(playersPseudo, this.Canvas);
    }
}