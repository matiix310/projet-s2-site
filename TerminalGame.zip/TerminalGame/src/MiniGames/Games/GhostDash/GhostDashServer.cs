using ProjS2.MiniGames.Tcp.Server;
using ProjS2.Utils;

namespace ProjS2.MiniGames.Games.GhostDash;

public class GhostDashServer : MiniGamesGameServer {
    
    private static Dictionary<string, (string representation, int spaceBottom)> _obstacles = new Dictionary<string, (string representation, int spaceBottom)>()
    {
        {"spike", ("▲", 0)},
        {"block2", ("▲\n▉", 0)}
    };
    
    private int _x;
    private System.Timers.Timer? _interval;
    private List<(string Name, int Position)> _placedObstacles;

    private int _minInterval;
    private int _maxInterval;
    
    private List<string?> _playersPseudo;
    private Dictionary<string?, (int LifeCount, int Distance, string Pseudo)> _playersData;
    private Canvas _canvas;
    
    private Server? _server;
    
    public GhostDashServer(List<string?> playersPseudo, Canvas canvas)
    {
        this._playersPseudo = playersPseudo;
        this._canvas = canvas;
        
        // set default attributes
        this._placedObstacles = new List<(string obstacleName, int coordinate)>();
        this._placedObstacles.Add(("spike", canvas.GetWidth()-3));
        this._minInterval = 10;
        this._maxInterval = 80;
        this._x = this._maxInterval;
        
        // init players data
        this._playersData = new Dictionary<string?, (int LifeCount, int Distance, string Pseudo)>();
        foreach (string? pseudo in playersPseudo)
            this._playersData.Add(pseudo, (3, 0, pseudo));
    }
    
    public override void Start(Server server)
    {
        this._server = server;

        // send the player list
        server.BroadcastMessage("updatePlayersData:" + GeneratePlayersData());
        
        Update();
    }
    
    public void Update()
    {
        if (!ArePlayersAlive())
        {
            EndGame();
            return;
        }
        
        if (this._interval is not null)
            this._interval.Stop();

        this._interval = TimerManager.SetInterval((_, e) =>
        {
            if (!ArePlayersAlive()) return;
            // update obstacle position
            UpdateObstacles();
        }, this._x);

        TimerManager.SetTimeout((_, e) =>
        {
            if (this._x > this._minInterval)
                this._x -= 1;
            Update();
        }, 2000);
    }
    
    private bool ArePlayersAlive()
    {
        foreach ((int LifeCount, int _d, string _p) player in this._playersData.Values)
            if (player.LifeCount > 0) return true;
        
        return false;
    }
    
    private void UpdateObstacles()
    {
        // update all obstacle positions
        for (int i = 0; i < this._placedObstacles.Count; i++)
            this._placedObstacles[i] = (this._placedObstacles[i].Name, this._placedObstacles[i].Position-1);
        
        // get the last obstacle coordinate
        int lastPos = 0;
        if (this._placedObstacles.Count > 0)
            lastPos = this._placedObstacles[^1].Position;

        // check if we place a new Obstacle
        if (lastPos < this._canvas.GetWidth()-30 && new Random().Next(0, lastPos) < this._canvas.GetWidth()/20)
        {
            //place a random obstacle
            string randomObstacleName = new List<string>(_obstacles.Keys)[new Random().Next(0, _obstacles.Count)];
            int position = this._canvas.GetWidth()-Common.GetStringSize(_obstacles[randomObstacleName].representation).Width-1;
            this._placedObstacles.Add((randomObstacleName, position));
            
            this._server.BroadcastMessage("placeObstacle:" + randomObstacleName + "," + position);
        }

        if (this._placedObstacles[0].Position < 0)
            this._placedObstacles.RemoveAt(0);
    }
    
    private void EndGame()
    {
        List<(int LifeCount, int Distance, string Pseudo)> playersData = this._playersData.Values.ToList();
        playersData.Sort((a, b) => a.Distance < b.Distance ? 1 : -1);

        List<string> output = new List<string>();

        for (int i = 0; i < playersData.Count; i++)
            output.Add(i + "," + playersData[i].Distance + "," + playersData[i].Pseudo);

        this._server.BroadcastMessage("ranking:" + String.Join(',', output));
    }

    public override void ReceiveMessage(string message)
    {
        if (!message.Contains(":")) return;

        string action = message.Split(":")[0];
        string data = message.Split(":")[1];

        switch (action)
        {
            case "updatePlayerData" :
                string?[] playerInfo = data.Split(',');
                this._playersData[playerInfo[2]] = (Int32.Parse(playerInfo[0]), Int32.Parse(playerInfo[1]), playerInfo[2]);
                this._server!.SendMessageToOtherClients(playerInfo[2], "updatePlayersData:" + GeneratePlayersData());
                break;

            case "setPos" :
                string? playerName = data.Split(',')[0];
                string playerPos = data.Split(',')[1];
                this._server!.SendMessageToOtherClients(playerName, "setPos:" + playerName + "," + playerPos);
                break;
        }
    }

    private string GeneratePlayersData()
    {
        List<string> playersData = new List<string>();
        foreach ((int LifeCount, int Distance, string Pseudo) playerData in this._playersData.Values)
            playersData.Add(playerData.LifeCount + "," + playerData.Distance + "," + playerData.Pseudo);

        return String.Join(',', playersData);
    }
}