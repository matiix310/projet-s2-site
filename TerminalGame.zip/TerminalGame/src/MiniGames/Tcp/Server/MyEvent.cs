using System;

namespace ProjS2.MiniGames.Tcp.Server;

public delegate void MyEventHandler(object source, MyEventArgs e);

public class MyEventArgs : EventArgs
{
    private string EventInfo;
    private string? Id;

    public MyEventArgs(string text, string? id)
    {
        this.EventInfo = text;
        this.Id = id;
    }

    public string GetInfo()
    {
        return EventInfo;
    }

    public string? GetId()
    {
        return Id;
    }
}