using System.Net.Sockets;
using System.Text;

namespace ProjS2.MiniGames.Tcp.Server;

public class Server {

    public int Port;
    public TcpListener TcpServer;
    public bool Listening;

    public Dictionary<string?, TcpClient> TcpClients;

    // event managment
    public static event MyEventHandler? OnMessageReceived;
    public static event MyEventHandler? OnPlayerConnect;
    public static event MyEventHandler? OnPlayerDisconnect;

    // send message to host
    private Action<string> _sendMessageToHost;

    private int _maxConnection;

    public Server(int port, int maxConnection, Action<string> sendMessageToHost)
    {
        this.Port = port;
        this.TcpServer = new TcpListener(port);
        this.Listening = false;
        this.TcpClients = new Dictionary<string?, TcpClient>();
        this._maxConnection = maxConnection;
        this._sendMessageToHost = sendMessageToHost;
    }

    public void StopListening()
    {
        this.Listening = false;
        BroadcastMessage("disconnect:_");
        this.TcpServer.Stop();
    }

    public void AddEventListener(string eventName, MyEventHandler eventHandler)
    {
        switch (eventName)
        {
            case "OnMessageReceived" :
                OnMessageReceived += eventHandler;
                break;
                
            case "OnPlayerConnect" :
                OnPlayerConnect += eventHandler;
                break;
                
            case "OnPlayerDisconnect" :
                OnPlayerDisconnect += eventHandler;
                break;
        }
    }

    public void StartListening()
    {
        this.TcpServer.Start();
        this.Listening = true;
        Byte[] bytes = new Byte[256];

        while(this.Listening)
        {
            Thread.Sleep(10);
            try
            {
                // wait for a new client
                TcpClient client = this.TcpServer.AcceptTcpClient();

                if (this.TcpClients.Count < this._maxConnection)
                {
                    Thread thread = new Thread (new ParameterizedThreadStart(ClientHandler));
                    thread.IsBackground = true;
                    thread.Start(client);
                }
                else
                {
                    SendMessage(client, "Error: the game is full !");
                    client.Close();
                }
            }
            catch (Exception e)
            {
//                Console.WriteLine(e);
            }
        }
    }

    private void ClientHandler(object c)
    {
        TcpClient client = (TcpClient)c;
        NetworkStream ns = client.GetStream();
        string? id = "";

        // read the is wich is the first message the server should received
        Thread.Sleep(10);

        try
        {
            byte[] bytes = new byte[client.ReceiveBufferSize];
            int i = ns.Read(bytes, 0, bytes.Length);

            // if the client disconnect
            if (i == 0) return;

            // get the id
            id = Encoding.ASCII.GetString(bytes, 0, i);

            // return if the id is already taken
            if (TcpClients.ContainsKey(id)) return;

            // add the client to the TcpClients dictionary
            TcpClients.Add(id, client);
        }
        catch (Exception e)
        {
            Console.WriteLine(e);
        }

        byte[] sendBytes = Encoding.UTF8.GetBytes("connected");
        ns.Write(sendBytes, 0, sendBytes.Length);

        // trigger the event
        if(OnPlayerConnect != null)
        {
            OnPlayerConnect(null, new MyEventArgs("", id));
        }

        // start listening for messages
        bool connected = true;
        while (connected)
        {
            Thread.Sleep(10);
            try
            {
                byte[] bytes = new byte[client.ReceiveBufferSize];
                int i = ns.Read(bytes, 0, bytes.Length);

                if (i == 0) connected = false;

                else {

                    string data = Encoding.ASCII.GetString(bytes, 0, i);

                    // send data to the event handler
                    if(OnMessageReceived != null)
                    {
                        // split the message with the message separator '|'
                        string[] splitedMessage = data.Split('|');
                        foreach (string message in splitedMessage)
                        {
                            OnMessageReceived(null, new MyEventArgs(message, id));
                        }
                    }
                }

            }
            catch (Exception e)
            {
                connected = false;
                Console.WriteLine(e);
                Console.WriteLine(e.StackTrace);
            }
        }

        // remove the client when the socket is disconnected
        TcpClients.Remove(id);
        
        if(OnPlayerDisconnect != null)
        {
            OnPlayerDisconnect(null, new MyEventArgs("", id));
        }
    }

    public void SendMessage(TcpClient tcpClient, string message)
    {
        string editedMessage = '|' + message;

        NetworkStream ns = tcpClient.GetStream();
        byte[] bytes = Encoding.UTF8.GetBytes(editedMessage);
        ns.Write(bytes, 0, bytes.Length);
    }

    public void SendMessage(string? id, string message)
    {
        if (!this.TcpClients.ContainsKey(id)) return;

        string editedMessage = '|' + message;

        NetworkStream ns = this.TcpClients[id].GetStream();
        byte[] bytes = Encoding.UTF8.GetBytes(editedMessage);
        ns.Write(bytes, 0, bytes.Length);
    }

    public void BroadcastMessage(string message)
    {
        SendMessageToEveryClients(message);
        SendMessageToHost(message);
    }

    public void SendMessageToEveryClients(string message)
    {
        foreach (string? id in TcpClients.Keys)
        {
            SendMessage(id, message);
        }
    }

    public void SendMessageToHost(string message)
    {
        this._sendMessageToHost(message);
    }

    public void SendMessageToOtherClients(string? excludedId, string message)
    {
        foreach (string? id in TcpClients.Keys)
            if (id != excludedId) SendMessage(id, message);

        SendMessageToHost(message);
    }

}