using System;

namespace ProjS2.MiniGames.Tcp.Client;

public delegate void MyEventHandler(object source, MyEventArgs e);

public class MyEventArgs : EventArgs
{
    private string EventInfo;

    public MyEventArgs(string text)
    {
        this.EventInfo = text;
    }

    public string GetInfo()
    {
        return EventInfo;
    }
}