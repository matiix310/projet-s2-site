using System.Net.Sockets;
using System.Text;
using ProjS2.Utils;

namespace ProjS2.MiniGames.Tcp.Client;

public class Client {

    public string Hostname;
    public int Port;
    public TcpClient TcpClient;
    public bool Listening;
    public string? Id;
    public bool Connected;

    public MyEventHandler? OnMessageReceived;
    public MyEventHandler? OnConnectionEstablished;
    public MyEventHandler? OnConnectionClose;

    public Thread ClientThread;

    public Client(string hostname, int port, string? id)
    {
        this.Hostname = hostname;
        this.Port = port;
        this.Id = id;
    }

    public void AddEventListener(string eventName, MyEventHandler myEventHandler)
    {
        switch (eventName)
        {
            case "OnMessageReceived" :
                this.OnMessageReceived += myEventHandler;
                break;

            case "OnConnectionEstablished" :
                this.OnConnectionEstablished += myEventHandler;
                break;

            case "OnConnectionClose" :
                this.OnConnectionClose += myEventHandler;
                break;
        }
    }

    public void Connect()
    {
        // try to connect to the server
        try
        {
            this.TcpClient = new TcpClient(this.Hostname, this.Port);
            // authentificate to the server
            this.Connected = EstablishConnection(this.Id);
        }
        catch (Exception e)
        {
            if (this.OnConnectionClose != null)
                OnConnectionClose(this, new MyEventArgs($"Unable to connect to the requested server : {this.Hostname}"));
        }

        if(this.Connected && this.OnConnectionEstablished != null)
        {
            OnConnectionEstablished(this, new MyEventArgs(null));
        }

        else if(!this.Connected && this.OnConnectionClose != null)
        {
            OnConnectionClose(this, new MyEventArgs("Impossible de se connecter au serveur !"));
        }
    }

    public void StopListening()
    {
        this.Listening = false;
    }

    public void StartListening()
    {
        if (!this.Connected)
        {
            if (this.OnConnectionClose != null)
                this.OnConnectionClose(null, new MyEventArgs("Client is not connected to any server !"));

            return;
        }
        this.Listening = true;
        this.ClientThread = new Thread(RunListener);
        this.ClientThread.Start();
    }

    private void RunListener()
    {
        Byte[] bytes = new Byte[256];
        NetworkStream stream = this.TcpClient.GetStream();

        while (this.Listening && this.Connected)
        {
            int i;

            // Loop to receive all the data sent by the client.
            while(this.Listening && this.Connected && (i = TryRead(stream, bytes))!=0)
            {
                // Translate data bytes to a ASCII string.
                string data = System.Text.Encoding.ASCII.GetString(bytes, 0, i);

                // send data to the event handler
                if(this.OnMessageReceived != null)
                {
                    string[] splitedMessage = data.Split('|');
                    foreach (string message in splitedMessage)
                    {
                        OnMessageReceived(this, new MyEventArgs(message));
                    }
                }
            }
        }
    }

    private int TryRead(NetworkStream stream, byte[] bytes)
    {
        try
        {
            return stream.Read(bytes, 0, bytes.Length);
        }
        catch (Exception e)
        {
            return 0;
        }
    }

    private bool EstablishConnection(string? id)
    {
        NetworkStream ns = this.TcpClient.GetStream();
        byte[] bytes = Encoding.UTF8.GetBytes(id);
        ns.Write(bytes, 0, bytes.Length);

        bytes = new Byte[256];
        int i = ns.Read(bytes, 0, bytes.Length);
        string response = Encoding.ASCII.GetString(bytes, 0, i);

        return response == "connected";
    }

    public void SendMessage(string message)
    {
        if (!this.Connected) return;

        string editedMessage = '|' + message;

        NetworkStream ns = this.TcpClient.GetStream();
        byte[] bytes = Encoding.UTF8.GetBytes(editedMessage);
        ns.Write(bytes, 0, bytes.Length);
    }

    public void Dispose()
    {
        this.Listening = false;
        this.Connected = false;
        try
        {
            this.TcpClient.Close();
        }
        catch (Exception e)
        {
//            Console.WriteLine(e);
        }
    }
}