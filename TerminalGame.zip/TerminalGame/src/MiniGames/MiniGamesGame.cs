using ProjS2.MiniGames.Tcp.Server;
using ProjS2.Utils;

namespace ProjS2.MiniGames;

public class MiniGamesGamePattern {
    
    protected readonly Canvas Canvas;
    protected readonly InputListener InputListener;

    public string Id;
    public string Name;
    public string Description;
    public int MaxPlayer;
    public int MinPlayer;
    
    public MiniGamesGamePattern(Canvas canvas, InputListener inputListener, string id, string name, string description, int maxPlayer, int minPlayer)
    {
        this.Canvas = canvas;
        this.InputListener = inputListener;
        this.Id = id;
        this.Name = name;
        this.Description = description;
        this.MaxPlayer = maxPlayer;
        this.MinPlayer = minPlayer;
    }
}

public abstract class MiniGamesGameClient : MiniGamesGamePattern {
    
    protected MiniGamesGameClient(Canvas canvas, InputListener inputListener, string id, string name, string description, int maxPlayer, int minPlayer) : base(canvas, inputListener, id, name, description, maxPlayer, minPlayer)
    {
    }

    public abstract void Start(List<string?> playersPseudo, Action<string>? sendToServer, string? pseudo, Action disposeClient, Action endTheGame);
    
    public abstract MiniGamesGameServer GetServer(List<string?> playersPseudo);

    public abstract void ReceiveMessage(string message);
}


public abstract class MiniGamesGameServer {

    protected MiniGamesGameServer()
    {
    }

    public abstract void Start(Server server);

    public abstract void ReceiveMessage(string message);
}