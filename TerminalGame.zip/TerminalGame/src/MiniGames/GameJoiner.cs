using System.Net;
using ProjS2.MiniGames.Games.GhostDash;
using ProjS2.MiniGames.Tcp.Client;
using ProjS2.Utils;

namespace ProjS2.MiniGames;

public class GameJoiner {
    
    private readonly Canvas _canvas;
    private readonly InputListener _inputListener;
    private readonly Menu _menu;
    private readonly string? _pseudo;
    private readonly MiniGamesMenu _miniGamesMenu;

    private List<string?> _playersPseudo;
    private bool _isConnected;
    private MiniGamesGameClient? _game;
    private string _errorMessage;
    private bool _gameStarted;
    
    private Client? _client;

    private string? _lastIp;

    public GameJoiner(Canvas canvas, InputListener inputListener, Menu menu, MiniGamesMenu miniGamesMenu, string? pseudo)
    {
        this._canvas = canvas;
        this._inputListener = inputListener;
        this._menu = menu;
        this._miniGamesMenu = miniGamesMenu;
        this._pseudo = pseudo;
        this._playersPseudo = new List<string?>();
        this._isConnected = false;
        this._errorMessage = "Connection ...";
        this._gameStarted = false;
    }

    public void Display()
    {
        CaptureInput();

        // ask for server ip
        string ip = InputReader.Read(this._canvas, this._menu, "Please enter the server IP:").Trim();

        // start the client
        StartClient(ip);

        // draw on the canvas
        Draw();
    }

    private void CaptureInput()
    {
        // reset listen keys
        this._inputListener.ResetListenedKeys();

        this._inputListener.ListenToInput(ConsoleKey.Escape, LeaveTheRoom);

        this._inputListener.StartListening();
    }

    private void LeaveTheRoom()
    {
        if (this._client != null)
            DisposeClient();
        this._miniGamesMenu.Start(this._pseudo);
    }

    private void DisposeClient()
    {
        this._client.Dispose();
    }

    public void Draw()
    {
        if (_gameStarted) return;
        if (this._game is null)
        {
            string connectionState = this._errorMessage;
            if (this._isConnected)
            {
                this._errorMessage = "Connected!";
            }
            (int Width, int Height) infoSize = (this._errorMessage.Length + 6, 5);

            int left = (this._canvas.GetWidth()-infoSize.Width)/2;
            int top = (this._canvas.GetHeight()-infoSize.Height)/2;

            // clear the old button
            this._canvas.Erase(0, top, this._canvas.GetWidth(), infoSize.Height);

            // draw the new one
            this._canvas.Write(Common.GenerateButton(connectionState, infoSize.Width, infoSize.Height), (this._canvas.GetWidth()-infoSize.Width)/2, (this._canvas.GetHeight()-infoSize.Height)/2);

        } else
        {
            // draw the blank table in the center (width)
            int tableWidth = 70;
            this._canvas.Write(GenerateTable(this._game.MaxPlayer, tableWidth), (this._canvas.GetWidth()-tableWidth)/2, 5);
        }

        // draw the launch button
        (int Width, int Height) buttonSize = (30, 5);

        this._canvas.Write(
            Common.GenerateButton("[Escape] : Leave the room", buttonSize.Width, buttonSize.Height),
            (this._canvas.GetWidth() - buttonSize.Width)/2,
            this._canvas.GetHeight()-7
            );
    }

    private string GenerateTable(int rowCount, int tableWidth)
    {
        string table = "";
        for (int i = 0; i < rowCount; i++)
        {
            if (i == 0)
                table += '╭' + new string('─', tableWidth-2) + "╮\n";
            else
                table += '├' + new string('─', tableWidth-2) + "┤\n";

            for (int j = 0; j < 3; j++)
            {
                if (j == 1 && i < this._playersPseudo.Count)
                {
                    int margin = tableWidth-2 - this._playersPseudo[i].Length;
                    table += '│' + new String(' ', margin/2) + this._playersPseudo[i] + new String(' ', margin/2 + margin%2) + "│\n";
                }
                else
                    table += '│' + new String(' ', tableWidth-2) + "│\n";;
            }
        }
        table += '╰' + new string('─', tableWidth-2) + '╯';

        return table;
    }

    public void StartClient(string serverIp)
    {
        // for testing
        System.Net.ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls12;

        // client
        this._client = new Client(serverIp, 1001, this._pseudo);

        // on connection established
        this._client.AddEventListener("OnConnectionEstablished", (_, e) =>
        {
            this._lastIp = serverIp;
            this._isConnected = true;
            Draw();
        });

        this._client.AddEventListener("OnConnectionClose", (_, e) =>
        {
            this._isConnected = false;
            this._game = null;
            this._errorMessage = e.GetInfo();
            Draw();
        });
        this._client.AddEventListener("OnMessageReceived", (_, e) =>
        {
            AnalyseMessage(e.GetInfo());
            Draw();
        });

        this._client.Connect();
        this._client.StartListening();
    }

    public void AnalyseMessage(string message)
    {
        if (!message.Contains(":")) return;

        if (this._gameStarted)
            this._game.ReceiveMessage(message);

        string action = message.Split(":")[0];
        string data = message.Split(":")[1];

        switch (action)
        {
            case "startGame" :
                this._game.Start(this._playersPseudo, this._client.SendMessage, this._pseudo, DisposeClient, () =>
                {
                    this._canvas.Clear();

                    if (this._lastIp is null)
                        LeaveTheRoom();

                    else
                    {
                        this._playersPseudo = new List<string?>();
                        this._isConnected = false;
                        this._errorMessage = "Connection ...";
                        this._gameStarted = false;
                        StartClient(this._lastIp);
                        CaptureInput();
                        Draw();
                    }
                });
                this._gameStarted = true;
                break;

            case "setGame" :
                switch (data)
                {
                    case "GhostDash" :
                        this._game = new GhostDashClient(this._canvas, this._inputListener);
                        break;
                }
                break;

            case "setPlayers" :
                this._playersPseudo = data.Split(",").ToList();
                break;

            case "disconnect" :
                this._game = null;
                this._isConnected = false;
                this._gameStarted = false;
                this._errorMessage = "Disconnected from the server!";
                break;
        }
    }
}