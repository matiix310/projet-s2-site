using System;
using ProjS2.Utils;
using ProjS2.MiniGames.Games;
using ProjS2.MiniGames.Games.GhostDash;

namespace ProjS2.MiniGames;

public class MiniGamesMenu {
    
    private readonly InputListener _inputListener;
    private readonly Canvas _canvas;
    private Menu _menu;
    
    private int _selectedRow;
    private (int ChoiceCount, int Selected)[] _rows;
    private readonly MiniGamesGameClient[] _miniGamesGames;
    private readonly string[] _modes;
    private string? _pseudo;
    
    public MiniGamesMenu(InputListener inputListener, Canvas canvas, Menu menu)
    {
        this._inputListener = inputListener;
        this._canvas = canvas;
        this._menu = menu;
        this._miniGamesGames = new MiniGamesGameClient[]
        {
            new GhostDashClient(this._canvas, this._inputListener),
        };
        this._modes = new string[]
        {
            "Host", "Join"
        };
        this._rows = new (int ChoiceCount, int Selected)[]
        {
            (this._modes.Length, 0),
            (this._miniGamesGames.Length, 0),
        };
        this._selectedRow = 0;
        this._pseudo = "";
    }
    
    public void Start(string? pseudo = "")
    {
        // setup listen inputs
        this._inputListener.ResetListenedKeys();

        // clear the canvas
        this._canvas.Clear();

        // get the player pseudo
        if (pseudo == "")
            this._pseudo = InputReader.Read(this._canvas, this._menu, "Please enter your pseudo:");
        else
            this._pseudo = pseudo;

        this._inputListener.ListenToInput(ConsoleKey.UpArrow, () =>
            {
                if (this._selectedRow > 0)
                {
                    this._selectedRow -= 1;
                    Draw();
                }
            });
        this._inputListener.ListenToInput(ConsoleKey.DownArrow, () =>
            {
                if (this._selectedRow < this._rows.Length - 1)
                {
                    this._selectedRow += 1;
                    Draw();
                }
            });
        this._inputListener.ListenToInput(ConsoleKey.LeftArrow, () =>
            {
                if (this._rows[this._selectedRow].Selected > 0)
                {
                    this._rows[this._selectedRow].Selected -= 1;
                    Draw();
                }
            });
        this._inputListener.ListenToInput(ConsoleKey.RightArrow, () =>
            {
                if (this._rows[this._selectedRow].Selected < this._rows[this._selectedRow].ChoiceCount - 1)
                {
                    this._rows[this._selectedRow].Selected += 1;
                    Draw();
                }
            });
        this._inputListener.ListenToInput(ConsoleKey.Spacebar, () =>
            {
                this._canvas.Clear();
                if (this._rows[0].Selected == 0)
                {
                    // start hosting
                    Host(this._miniGamesGames[this._rows[1].Selected], this._pseudo);
                } else
                {
                    // start joining
                    Join(this._pseudo);
                }
            });
        this._inputListener.ListenToInput(ConsoleKey.Escape, this._menu.DisplayMenu);
        this._inputListener.StartListening();
        Draw();
    }
    
    public void Draw()
    {
        // draw the pseudo info
        this._canvas.Write("Pseudo : " + this._pseudo, 10, 3);

        // clear second button
        string clearStr = new string(' ', this._canvas.GetWidth());
        for (int i = 0; i < 7; i++)
            clearStr += "\n" + new string(' ', this._canvas.GetWidth());
        this._canvas.Write(clearStr, 0, 25);

        // minigame selector
        DrawSelector(10, this._modes[this._rows[0].Selected], "Selected game mode:", 0);

        // host game
        if (this._rows[0].Selected == 0)
        {
            this._rows = new (int ChoiceCount, int Selected)[]
            {
                (this._modes.Length, 0),
                this._rows.Length == 2 ? this._rows[1] : (this._miniGamesGames.Length, 0),
            };
            DrawSelector(25, this._miniGamesGames[this._rows[1].Selected].Name, "Selected minigame:", 1);
        } else
        {
            this._rows = new (int ChoiceCount, int Selected)[]
            {
                (this._modes.Length, 1),
            };
        }

        // draw the launch button
        (int Width, int Height) buttonSize = (30, 5);
        int spaceBetween = 30;

        this._canvas.Write(
            Common.GenerateButton("[SpaceBar] : Validate", buttonSize.Width, buttonSize.Height),
            (this._canvas.GetWidth() - spaceBetween)/2 - buttonSize.Width,
            this._canvas.GetHeight()-7
        );

        this._canvas.Write(
            Common.GenerateButton("[Escape] : Exit", buttonSize.Width, buttonSize.Height),
            (this._canvas.GetWidth() + spaceBetween)/2,
            this._canvas.GetHeight()-7
        );
    }
    
    public void DrawSelector(int top, string buttonContent, string label, int rowIndex)
    {
        (int Width, int Height) buttonSize = (40, 5);
        
        // draw the button
        // top border
        string button = '╭' + new String('─', buttonSize.Width-2) + "╮\n";
        
        // blank
        for (int i = 0; i < (buttonSize.Height-3)/2; i++)
            button += '│' + new String(' ', buttonSize.Width-2) + "│\n";
        
        // buttonContent
        int freeSpace = (buttonSize.Width - 2 - buttonContent.Length);
        button += '│' + new String(' ', freeSpace/2) + buttonContent + new String(' ', freeSpace/2 + freeSpace%2) + "│\n";
        
        // blank
        for (int i = 0; i < (buttonSize.Height-3)/2 + (buttonSize.Height-3)%2; i++)
            button += '│' + new String(' ', buttonSize.Width-2) + "│\n";
        
        // bottom border
        button += '╰' + new String('─', buttonSize.Width-2) + '╯';
        
        int left = (this._canvas.GetWidth()-buttonSize.Width)/2;
        
        this._canvas.Write(label, (this._canvas.GetWidth()-label.Length)/2, top);
        this._canvas.Write(button, left, top+3);

        // draw arrows
        bool isSelected = rowIndex == this._selectedRow;
        string leftArrow = isSelected && this._rows[rowIndex].Selected != 0 ? "<" : " ";
        string rightArrow = isSelected && this._rows[rowIndex].Selected != this._rows[rowIndex].ChoiceCount-1 ? ">" : " ";
        this._canvas.Write(leftArrow, left-5, top+3 + buttonSize.Height/2);
        this._canvas.Write(rightArrow, left+buttonSize.Width+4, top+3 + buttonSize.Height/2);
    }

    public void Host(MiniGamesGameClient game, string? pseudo)
    {
        GameHoster gameHoster = new GameHoster(this._canvas, this._inputListener, this, game, pseudo);
        gameHoster.Display();
    }

    public void Join(string? pseudo)
    {
        GameJoiner gameJoiner = new GameJoiner(this._canvas, this._inputListener, this._menu, this, this._pseudo);
        gameJoiner.Display();
    }
}