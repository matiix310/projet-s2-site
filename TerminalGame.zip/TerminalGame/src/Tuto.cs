﻿using ProjS2.Utils;

namespace ProjS2;

public class Tuto
{
    private Canvas _canvas;
    private int _weigth;
    private int _height;
    private string[]? _listString;
    private int _selectedIndex = 0;
    private InputListener _inputListener;
    public bool _quit = false;
    private Action _startGame;
    private ConfigFile? _config;
    private bool rightArrow;
    public Tuto(Canvas Canvas,ConfigFile config,InputListener inputListener, Action startGame)
    {
        _inputListener = inputListener;
        _canvas = Canvas;
        _weigth = _canvas.GetBufferWidth();
        _height = _canvas.GetHeight();
        _config = config;
        _listString = _config?.paths?.tuto;
        this._startGame = startGame;
    }

    public void Draw()
    {
        _inputListener.ResetListenedKeys();
        this.GetInputListener().ListenToInput(ConsoleKey.RightArrow, () =>
        {
            
            if (_selectedIndex < _listString?.Length-1)
            {
                _canvas.Clear();
                _selectedIndex++;
                Update();
                rightArrow = true;
            }
        });
        this.GetInputListener().ListenToInput(ConsoleKey.LeftArrow, () =>
        {
            
            if (_selectedIndex > 0)
            {
                _canvas.Clear();
                _selectedIndex--;
                Update();
                rightArrow = false;
            }
            
        });
        this.GetInputListener().ListenToInput(ConsoleKey.Spacebar, () =>
        {
            Quit();
        });
        _inputListener.StartListening();
        Update();
    }

    public void Quit()
    {
        this._quit = true;
        this._startGame();
    }

    public void Update()
    {
        string output = FileManager.GetFile(_listString?[_selectedIndex]);
        _canvas.Write(output,0,0);
    }

    public InputListener GetInputListener()
    {
        return _inputListener;
    }
}