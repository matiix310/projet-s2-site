using ProjS2.Utils;
using Timer = System.Timers.Timer;

namespace ProjS2
{
    public class PauseMenu {

        private readonly Canvas _canvas;
        private readonly (int width, int height) _buttonSize;
        private readonly PauseButton[] _pauseButtons;
        private readonly Game _game;

        private Timer? _thread;

        public int Selected;

        public PauseMenu(Canvas canvas, Game game, PauseButton[] pauseButtons) {
            this._canvas = canvas;
            this._buttonSize = (20, 3);
            this._pauseButtons = pauseButtons;
            this._pauseButtons[this.Selected].Select(true);
            this._game = game;

            this.Selected = 0;

            this._thread = new Timer();
        }

        public void DisplayPauseMenu() {
            foreach(PauseButton button in this._pauseButtons) {
                button.Draw();
            }
        }

        public void GetInput() {
            // check if a key is pressed
            if (Console.KeyAvailable) {
                ConsoleKeyInfo key = Console.ReadKey(true);

                switch (key.Key) {
                    case ConsoleKey.UpArrow :
                        if (this.Selected <= 0) return;
                        this._pauseButtons[this.Selected].Select(false);
                        this.Selected -= 1;
                        this._pauseButtons[this.Selected].Select(true);
                        break;
                    case ConsoleKey.DownArrow :
                        if (this.Selected >= this._pauseButtons.Length-1) return;
                        this._pauseButtons[this.Selected].Select(false);
                        this.Selected += 1;
                        this._pauseButtons[this.Selected].Select(true);
                        break;
                    case ConsoleKey.Spacebar :
                        this._pauseButtons[this.Selected].DoAction();
                        break;
                }
            }
        }

        public void Show()
        {
            this._thread = TimerManager.SetInterval((Object ?_, System.Timers.ElapsedEventArgs _) =>
            {
                DisplayPauseMenu();
            }, 500);

            while (this._game.GetPauseState() && this._game.IsGame) GetInput();
        }

        public void Hide()
        {
            this._thread.Dispose();
        }
    }

    public class PauseButton : Drawable {

        private readonly Canvas _canvas;
        private readonly Action _action;
        private readonly int _height;
        private readonly int _width;
        private readonly int _x;
        private readonly int _y;
        private bool _selected;

        public string Label;

        public PauseButton(int? width, int? height, int? x, int? y, string label, Canvas canvas, Action action) {
            this._height = (int) height!;
            this._width = (int) width!;
            this._x = (int) x!;
            this._y = (int) y!;
            this._canvas = canvas;
            this._action = action;
            this._selected = false;

            this.Label = label;
        }

        public void DoAction() {
            this._action();
        }

        public override void Draw() {
            string[] button = GenerateButtonString(this.Label, this._width, this._height).Split("\n");

            for (int y = 0; y < button.Length; y++) {
                Console.SetCursorPosition(this._x, this._y + y);
                Console.Write(button[y]);
            }
            
            // draw / erase selection arrow
            Console.SetCursorPosition((this._canvas.GetWidth()-this._width)/2 - 4, this._y + this._height/2);
            Console.Write(this._selected ? ">" : "  ");
            Console.SetCursorPosition((this._canvas.GetWidth()+this._width)/2 + 2, this._y + this._height/2);
            Console.Write(this._selected ? "<" : "  ");
        }

        public override int GetHeight() => this._height;

        public override int GetWidth() => this._width;

        public void Select(bool state) {
            this._selected = state;
        }

        private string GenerateButtonString(string label, int width, int height) {
            if (height < 3) return label;

            string output = "";
            label = label.ToUpper();

            for (int i = 1; i < height-1; i++) {
                if (i == height/2) {
                    // add label
                    output += "║" + new string(' ', (width-2 - label.Length)/2) + label + new string(' ', width - label.Length-2 - (width-2 - label.Length)/2) + "║\n";
                } else output += "║" + new string(' ', width-2) + "║\n";
            }

            output = "╔" + new string('═', width-2) + "╗\n" + output + "╚" + new string('═', width-2) + "╝";

            return output;
        }
    }
}