using ProjS2.Utils;
using ProjS2.MiniGames;
using ProjS2.TerminalGame;
using Timer = System.Timers.Timer;

namespace ProjS2;

public class Menu {

    private readonly InputListener _inputListener;
    private readonly Canvas _canvas;
    private readonly ConfigFile _configFile;
    private Timer? _mainThread;
    private bool _canvasUpdateState;
    private int _selected;
    public int Fps = 5;

    public bool IsGameRunning;

    public Menu(int width, int height, int bufferWidth)
    {
        this.IsGameRunning = true;
        this._canvas = new Canvas(width, height, bufferWidth);
        this._inputListener = new InputListener(this);
        this._canvasUpdateState = true;
        this._selected = 0;
        this._configFile = FileManager.GetConfigFile();
    }

    public void Start()
    {
        // adjust the zoom level
        (int Width, int Height) size = (Console.WindowWidth, Console.WindowHeight);;

        if (size.Width < this._canvas.GetWidth() || size.Height < this._canvas.GetHeight())
        {
            Console.WriteLine("The screen is too small to display the game !\nYou need to adjust your terminal zoom level with ctrl + and ctrl -.");

            bool adjustZoom = true;
            while (adjustZoom)
            {
                (int Width, int Height) oldSize = (Console.WindowWidth, Console.WindowHeight);
                if (size != oldSize)
                {
                    Console.WriteLine("Actual size : " + size);
                    size = oldSize;

                    if (size.Width >= this._canvas.GetWidth() && size.Height >= this._canvas.GetHeight())
                    {
                        adjustZoom = false;
                    }
                }
            }
        }

        // initiate the canvas
        this._canvas.DrawCanvas();

        RestartActualisationThread();

        DisplayMenu();

        // the function that keeps the game alive
        this._inputListener.StartMainThread();
    }

    public void RestartActualisationThread()
    {
        if (this._mainThread is not null)
            this._mainThread.Stop();

        // define fps
        // and main thread for actualisation
        this._mainThread = TimerManager.SetInterval((Object ?_, System.Timers.ElapsedEventArgs _) => {
            if (this.IsGameRunning && this._canvasUpdateState) this._canvas.Update();
        }, 1000/Fps);
    }

    public void SetCanvasUpdateState(bool state) => this._canvasUpdateState = state;

    public void DisplayMenu()
    {
        this._selected = 0;
        int buttonsCount = 4;

        this._inputListener.ResetListenedKeys();
        this._inputListener.StartListening();
        this._inputListener.ListenToInput(ConsoleKey.Spacebar, ButtonClick);
        this._inputListener.ListenToInput(ConsoleKey.UpArrow, () =>
        {
            if (this._selected > 0)
            {
                this._selected -= 1;
                Draw();
            }
        });
        this._inputListener.ListenToInput(ConsoleKey.DownArrow, () =>
        {
            if (this._selected < buttonsCount-1)
            {
                this._selected += 1;
                Draw();
            }
        });

        this._canvas.Clear();
        Draw();
    }

    public void Draw()
    {
        // selectors
        string leftSelector = "  ┌─\n│ │\n│ │\n│ │\n│ │\n│ │\n│ │\n│ │\n│ │\n  └─";
        string rightSelector = "─┐  \n │ │\n │ │\n │ │\n │ │\n │ │\n │ │\n │ │\n │ │\n─┘";
        (int Width, int Height) selectorSize = (4, 10);

        // menu properties
        string menuTxt = FileManager.GetFile(this._configFile.paths!.images!.menu);
        (int Width, int Height) menuSize = Common.GetStringSize(menuTxt);
        int leftPos = (this._canvas.GetWidth() - menuSize.Width) / 2;
        (int Width, int Height) buttonSize = (33, 8);
        int separatorHeight = 2;

        // display the menu
        this._canvas.Write(menuTxt, leftPos, 0);

        // compute selectors position
        (int X, int Y) leftSelectorPos = (leftPos - selectorSize.Width - 2, this._selected * (buttonSize.Height + separatorHeight) + separatorHeight);
        (int X, int Y) rightSelectorPos = (leftPos + buttonSize.Width + 2, this._selected * (buttonSize.Height + separatorHeight) + separatorHeight);

        // erase the old selectors
        EraseSelector(leftPos, menuSize.Height + 1, selectorSize.Width, buttonSize.Width);

        // draw the selectors
        this._canvas.Write(leftSelector, leftSelectorPos.X, leftSelectorPos.Y);
        this._canvas.Write(rightSelector, rightSelectorPos.X, rightSelectorPos.Y);
    }

    public void EraseSelector(int leftPos, int menuHeight, int selectorWidth, int buttonWidth)
    {
        this._canvas.Erase(leftPos - selectorWidth - 2, 0, selectorWidth, menuHeight);
        this._canvas.Erase(leftPos + buttonWidth + 2, 0, selectorWidth, menuHeight);
    }

    public void ButtonClick()
    {
        switch (this._selected)
        {
            // solo
            case 0:
                this._canvas.Clear();
                Game game = new Game(this._inputListener, this._canvas, this);
                game.Start();
                break;

            // multiplayer
            case 1:
                this._canvas.Clear();
                MiniGamesMenu miniGamesMenu = new MiniGamesMenu(this._inputListener, this._canvas, this);
                miniGamesMenu.Start();
                break;

            // options
            case 2:
                this._canvas.Clear();
                Option option = new Option(_canvas, _inputListener, this);
                option.Draw();
                break;

            // leave the games
            case 3:
                this.IsGameRunning = false;
                this._canvas.Clear();
                Console.CursorVisible = true;
                break;
        }
    }
}