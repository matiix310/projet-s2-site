using ProjS2.RpgGame;
using ProjS2.Utils;

namespace ProjS2.TerminalGame;

public class Terminal : Drawable {

    public string Username;

    private readonly Game _game;
    private readonly Canvas _canvas;
    private readonly int _width;
    private readonly int _height;
    private readonly Tree _tree;
    private readonly InputListener _inputListerner;
    private readonly CommandManager _commandManager;

    public SaveManager SaveManager;
    public CommandSelector CommandSelector;

    public Terminal(Canvas canvas, int width, int height, int bufferWidth, ConfigFile? configFile, InputListener inputListener, SaveManager saveManager, Game game) {
        this._canvas = canvas;
        this._width = width;
        this._height = height;
        this._game = game;
        this._inputListerner = inputListener;
        this.SaveManager = saveManager;

        // define Tree structure
        this._tree = new Tree(this._canvas, width-bufferWidth, 25, saveManager.LoadedStage!);

        this.Username = "user@HB-Laptop-15-tz5rr";

        // setup the command manager to display and execute all the commands
        this._commandManager = new CommandManager(canvas, this, canvas.GetBufferWidth(), canvas.GetHeight());

        // define command selector
        this.CommandSelector = new CommandSelector(_canvas, width-bufferWidth, height-25, this, configFile, this._commandManager, game);

        this.SaveManager.LoadTerminalComponents(this);
    }

    public InputListener GetInputListener()
    {
        return _inputListerner;
    }

    // getter and setter for the current location
    public List<string> GetLocation() => this._game.Location;
    public List<string> SetLocation(List<string> location) => this._game.Location = location;

    public override void Draw()
    {
        if (!this._game.TerminalState)
            return;

        this.CommandSelector.Draw();
        Update();
    }

    public void Update()
    {
        if (!this._game.TerminalState)
            return;

        // draw the components of the terminal
        this._tree.Draw();
        this.CommandSelector.Update();
        this._commandManager.Draw();

        // must be on top of everything
        this._canvas.DisplayRectangleWithText(this._game.DisplayedHint, 45, 0, 80, 7);
    }

    public override int GetHeight() => this._height;
    public override int GetWidth() => this._width;

    // getch all the CustomFiles inside the current location
    public CustomFile[] GetLocationFolder()
    {
        CustomFile[] root = this.SaveManager.LoadedStage!.folders[0].content;
        CustomFile[] folder = root;

        foreach (string f in this._game.Location)
            folder = folder.ToList().Find(cf => cf.name == f)!.content;

        return folder;
    }

    // get the rpg player
    public Player GetPlayer() => this._game.Rpg.GetPlayerRpg();

    // getter and setter for the IsKing attribut of Game
    public void SetIsKing(bool isKing) => this._game.IsKing = isKing;
    public bool GetIsKing() => this._game.IsKing;
}