using ProjS2.RpgGame;
using ProjS2.Utils;

namespace ProjS2.TerminalGame.Commands;

public class CommandPython : Command {

    public CommandPython(Terminal terminal, Game game, CommandManager commandManager) : base(terminal, game, commandManager, "python", "Execute a python script.", new[] {"target"})
    {
    }

    public override string Execute(string[] args)
    {
        if (args.Length <= 0)
            return "You have to specify a script to execute!";
        
        CustomFile? target = this.Terminal.GetLocationFolder().ToList().Find(cf => cf.name == args[0]);
        
        if (target is null)
            return "The script '" + args[0] + "' does not exist!";
        
        if (target.state != "unlocked")
            return "Access denied!";
            
        if (target.name != "Tablet.py")
            return "The file '" + args[0] + "' is not a valid python script!";
        
        // unlock the secret folder and the files inside
        this.Terminal.SaveManager.EditCustomFileStateAndVisibility(new List<string>() { "Outer_court", "Castle", "Secret" }, "unlocked", true);
        this.Terminal.SaveManager.EditCustomFileStateAndVisibility(new List<string>() { "Outer_court", "Castle", "Secret", "MySecret" }, "unlocked", true);
        
        // change the username
        this.Terminal.Username = "root";

        // set isKing to true
        bool oldKingState = this.Terminal.GetIsKing();
        this.Terminal.SetIsKing(true);
        
        this.Terminal.GetPlayer().UpdateSkin();

        string[] combinations = new string[]
        {
            "Runing python script: " + args[0] + ".",
            "Starting injection...                          OK",
            "Establishing the connection to the server...   OK",
            "Fetching environment variables...              OK",
            "Getting root perimision...                     OK"
        };

        return String.Join('\n', combinations) + (oldKingState ? "\nSwitching user account...                      FAIL\nYou already are a root!" : "\nSwitching user account...                      OK\nYour naw logged in as root, wich means now have the keys of the kingdom (a full acces to the machine).");
    }

    public override void GetNewCommandButtons(Action<List<CommandButton>> setButtons)
    {
        List<CommandButton> commandButtons = new List<CommandButton>();

        // get all the files / folders
        List<CustomFile> customFiles = this.Terminal.GetLocationFolder().ToList();
        
        // filter the visible files
        customFiles = customFiles.FindAll(cf => cf.visible && cf.name.EndsWith(".py"));

        foreach (CustomFile cf in customFiles)
        {
            commandButtons.Add(new CommandButton(cf.name, () =>
            {
                // execute the command and display it into the CommandManager
                this.CommandManager.ExecuteCommand(this, new string[] { cf.name });
            }));
        }

        setButtons(commandButtons);
    }
}