namespace ProjS2.TerminalGame.Commands;

public abstract class Command {

    public string Name;
    public string Description;
    public string[] AvailibleArgs;

    protected readonly Game Game;
    protected readonly Terminal Terminal;
    protected readonly CommandManager CommandManager;

    protected Command(Terminal terminal, Game game, CommandManager commandManager, string name, string description, string[] availibleArgs)
    {
        this.Name = name;
        this.Description = description;
        this.AvailibleArgs = availibleArgs;
        this.Terminal = terminal;
        this.Game = game;
        this.CommandManager = commandManager;
    }

    public abstract string Execute(string[] args);

    public abstract void GetNewCommandButtons(Action<List<CommandButton>> setButtons);
}