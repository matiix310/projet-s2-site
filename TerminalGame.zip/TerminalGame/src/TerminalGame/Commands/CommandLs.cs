using ProjS2.Utils;

namespace ProjS2.TerminalGame.Commands;

public class CommandLs : Command {

    public CommandLs(Terminal terminal, Game game, CommandManager commandManager) : base(terminal, game, commandManager, "ls", "Print the files and folders inside your location", Array.Empty<string>())
    {
    }

    public override string Execute(string[]? args)
    {
        CustomFile[] root = this.Terminal.SaveManager.LoadedStage.folders![0].content;
        CustomFile[] folder = root;
        string output = "";

        foreach (string f in this.Game.Location)
            folder = folder.ToList().Find(cf => cf.name == f)!.content;

        foreach (CustomFile cf in folder)
        {
            output += FileManager.GetCfNameFormat(cf) + "    ";
        }

        if (output.Length >= 4)
            output.Substring(output.Length-4, 4);

        return output;
    }

    public override void GetNewCommandButtons(Action<List<CommandButton>> setButtons)
    {
    }
}