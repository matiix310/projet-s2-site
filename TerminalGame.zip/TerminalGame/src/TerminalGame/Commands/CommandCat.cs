using ProjS2.Utils;

namespace ProjS2.TerminalGame.Commands;

public class CommandCat : Command {

    public CommandCat(Terminal terminal, Game game, CommandManager commandManager) : base(terminal, game, commandManager, "cat", "Display the content of a file.", new[] {"target"})
    {
    }

    public override string Execute(string[] args)
    {

        if (args.Length <= 0) throw new Exception("You have to provide at least one argument to execute this command");

        CustomFile[] root = this.Terminal.SaveManager.LoadedStage.folders![0].content;
        CustomFile[] files = root;

        for (int i = 0; i < this.Game.Location.Count; i++)
            files = files.ToList().Find(cf => cf.name == this.Game.Location[i])!.content;

        CustomFile? target = files.ToList().Find(cf => cf.name == args[0]);
        
        if (target == null || !target.visible)
            return "Didn't find the file you're looking for.";

        if (target.state == "locked")
            return "Acces denied!";

        return target.textContent;
    }

    public override void GetNewCommandButtons(Action<List<CommandButton>> setButtons)
    {
        List<CommandButton> commandButtons = new List<CommandButton>();

        // get all the files / folders
        List<CustomFile> customFiles = this.Terminal.GetLocationFolder().ToList();
        
        // filter the visible files
        customFiles = customFiles.FindAll(cf => cf is { visible: true, type: "file" });

        foreach (CustomFile cf in customFiles)
        {
            commandButtons.Add(new CommandButton(cf.name, () =>
            {
                // execute the command and display it into the CommandManager
                this.CommandManager.ExecuteCommand(this, new string[] { cf.name });
            }));
        }

        setButtons(commandButtons);
    }
}