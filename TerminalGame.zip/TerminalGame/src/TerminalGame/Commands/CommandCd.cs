using ProjS2.Utils;

namespace ProjS2.TerminalGame.Commands;

public class CommandCd : Command {

    public CommandCd(Terminal terminal, Game game, CommandManager commandManager) : base(terminal, game, commandManager, "cd", "Change your location to the one given in argument.", new[] {"location"})
    {
    }

    public override string Execute(string[] args)
    {

        if (args.Length <= 0) throw new Exception("You have to provide at least one argument to execute this command");

        CustomFile[] root = this.Terminal.SaveManager.LoadedStage.folders![0].content;
        CustomFile[] folder = root;
        string newLocation;

        if (args[0] == "../" || args[0] == "..")
        {
            if (this.Game.Location.Count > 0)
            {
                this.Game.Location.RemoveAt(this.Game.Location.Count - 1);
                newLocation = (this.Game.Location.Count > 0 ? this.Game.Location.Last() : this.Terminal.SaveManager.LoadedStage.folders[0].name);

            } else return "If you want to leave the game just press \'Escape\'...";

        } else {

            bool parent = (args[0].Length > 3 && args[0].StartsWith("../"));

//            if (parent) args[0].Substring(0, 3);

            for (int i = 0; i < this.Game.Location.Count - (parent ? 1 : 0); i++)
                folder = folder.ToList().Find(cf => cf.name == this.Game.Location[i])!.content;

            CustomFile? destination = folder.ToList().Find(cf => cf.name == args[0]);
            if (destination == null || !destination.visible) return "Didn't find the directory you're looking for.";

            if (parent) this.Game.Location.RemoveAt(this.Game.Location.Count - 1);

            else if (destination.type != "folder")
                return "You can't get in a file.";

            else if (destination.state == "locked")
                return "Acces denied!";

            else
                this.Game.Location.Add(args[0]);

            newLocation = args[0];
        }

        return "Your now in " + newLocation + ".";
    }

    public override void GetNewCommandButtons(Action<List<CommandButton>> setButtons)
    {
        List<CommandButton> commandButtons = new List<CommandButton>();

        // get all the files / folders
        List<CustomFile> customFolders = this.Terminal.GetLocationFolder().ToList();

        // filter the visible folders
        customFolders = customFolders.FindAll(cf => cf is { visible: true, type: "folder" });

        foreach (CustomFile folder in customFolders)
        {
            commandButtons.Add(new CommandButton(folder.name + '/', () =>
            {
                // execute the command and display it into the CommandManager
                this.CommandManager.ExecuteCommand(this, new string[] { folder.name });

                GetNewCommandButtons(setButtons);
            }));
        }

        // add the back button
        if (this.Terminal.GetLocation().Count != 0)
            commandButtons.Add(new CommandButton("../", () =>
            {
                // execute the command and display it into the CommandManager
                this.CommandManager.ExecuteCommand(this, new string[] { "../" });

                GetNewCommandButtons(setButtons);
            }));

        setButtons(commandButtons);
    }
}