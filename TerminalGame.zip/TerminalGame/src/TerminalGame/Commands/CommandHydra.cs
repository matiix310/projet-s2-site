using ProjS2.RpgGame;
using ProjS2.Utils;

namespace ProjS2.TerminalGame.Commands;

public class CommandHydra : Command {

    public CommandHydra(Terminal terminal, Game game, CommandManager commandManager) : base(terminal, game, commandManager, "hydra", "Brute-force a file or a folder.", new[] {"target"})
    {
    }

    public override string Execute(string[] args)
    {
        if (args.Length <= 0)
            return "You have to specify a file to brute-force!";
        
        CustomFile? target = this.Terminal.GetLocationFolder().ToList().Find(cf => cf.name == args[0]);
        
        if (target is null)
            return "The file '" + args[0] + "' does not exist!";
            
        if (target.name != "Secret_door" || target.state != "locked")
            return "The file '" + args[0] + "' is not a valid target!";
        
        // unlock the file
        string[] filePath = new string[this.Terminal.GetLocation().Count + 1];
        this.Terminal.GetLocation().CopyTo(filePath);
        filePath[^1] = args[0];
        this.Terminal.SaveManager.EditCustomFileStateAndVisibility(filePath.ToList(), "unlocked", true);
        filePath[^1] = "Castle";
        this.Terminal.SaveManager.EditCustomFileStateAndVisibility(filePath.ToList(), "unlocked", true);
        this.Terminal.SaveManager.EditCustomFileStateAndVisibility(filePath.Append("Secret").ToList(), "locked", true);
        this.Terminal.SaveManager.EditCustomFileStateAndVisibility(filePath.Append("Tablet.py").ToList(), "locked", true);

        // change the secret door state
        NPC secretDoor = this.Game.Rpg.NPCs[1].Find(item => item.Id == "secretDoor");
        if (secretDoor is not null)
            secretDoor.State = 1;

        string[] combinations = new string[]
        {
            "1234 - Fail", "4321 - Fail", "0000 - Fail", "6666 - Fail", "1111 - Fail", "1412 - Fail", "4242 - OK"
        };

        return "Tesing all the possible combinations:\n" + String.Join('\n', combinations) + "\nThe file '" + args[0] + "' is now unlocked!";
    }

    public override void GetNewCommandButtons(Action<List<CommandButton>> setButtons)
    {
        List<CommandButton> commandButtons = new List<CommandButton>();

        // get all the files / folders
        List<CustomFile> customFiles = this.Terminal.GetLocationFolder().ToList();
        
        // filter the visible files
        customFiles = customFiles.FindAll(cf => cf is { visible: true, state: "locked" });

        foreach (CustomFile cf in customFiles)
        {
            commandButtons.Add(new CommandButton(cf.name, () =>
            {
                // execute the command and display it into the CommandManager
                this.CommandManager.ExecuteCommand(this, new string[] { cf.name });
            }));
        }

        setButtons(commandButtons);
    }
}