using System.Collections;
using ProjS2.TerminalGame.Commands;
using ProjS2.Utils;

namespace ProjS2.TerminalGame;

public class CommandSelector : Drawable {

    private readonly int _height;
    private readonly int _width;
    private readonly Canvas _canvas;
    private readonly Terminal _terminal;
    private readonly CommandManager _commandManager;
    public List<CommandButton> _buttons;
    private Game _game;
    public int Selected; // Index de la liste de boutton
    private readonly ConfigFile _file; // Acces au fichier
    private readonly int _buttonWidth = 30;

    public List<Command> DefaultCommands;

    public CommandSelector(Canvas canvas, int width, int height, Terminal terminal, ConfigFile? configFile, CommandManager commandManager, Game game)
    {
        this._canvas = canvas;
        this._width = width;
        this._height = height;
        this.Selected = 0;
        this._terminal = terminal;
        this._file = configFile!;
        this._buttons = new List<CommandButton>();
        this._commandManager = commandManager;
        this._game = game;
        this.DefaultCommands = new List<Command>();
    }

    public Command ParseCommand(string commandName)
    {
        switch(commandName)
        {
            case "cd":
                return new CommandCd(this._terminal, this._game, this._commandManager);

            case "ls":
                return new CommandLs(this._terminal, this._game, this._commandManager);

            case "cat":
                return new CommandCat(this._terminal, this._game, this._commandManager);

            case "hydra":
                return new CommandHydra(this._terminal, this._game, this._commandManager);

            case "python":
                return new CommandPython(this._terminal, this._game, this._commandManager);
        }

        throw new Exception("The command \"" + commandName + "\" is not recognized!");
    }

    public override void Draw()
    {
        this._terminal.GetInputListener().ListenToInput(ConsoleKey.Spacebar, () =>
        {
            this._buttons[this.Selected].Action();
            this.Selected = 0;
            Update();
        });
        
        // add the input listener to change and select a button
        // down arrow
        this._terminal.GetInputListener().ListenToInput(ConsoleKey.DownArrow, () =>
        {
            if (this.Selected < this._buttons.Count-1)
            {
                this.Selected += 1;
                this.Update();
            }
        });

        // up arrow
        this._terminal.GetInputListener().ListenToInput(ConsoleKey.UpArrow, () =>
        {
            if (this.Selected > 0)
            {
                this.Selected -= 1;
                this.Update();
            }
        });

        // Setup the default buttons and draw the selector
        ResetButtonsList();
        Update();
    }

    public void Update()
    {
        // update the selected button
        UpdateSelectedButton();

        string output = "";
        int topMargin = 1;

        // top margin
        for (int i = 0; i < topMargin; i++)
            output += '║' + new string(' ', this._width-2) + "║\n";

        // title
        string title = "Create your command:";
        int horizontalMarginTitle = (this._width-title.Length)/2 - 1;
        output += '║' + new string(' ', horizontalMarginTitle) + title + new string(' ', this._width-2-horizontalMarginTitle-title.Length) + "║\n";

        // margin
        output += '║' + new string(' ', this._width-2) + "║\n";

        // location
        string location = '/' + String.Join('/', this._game.Location);
        int horizontalMarginLocation = (this._width-location.Length)/2 - 1;
        output += '║' + new string(' ', horizontalMarginLocation) + location + new string(' ', this._width-2-horizontalMarginLocation-location.Length) + "║\n";

        // margin below the title
        int spaceBelowTitle = 1;
        for (int i = 0; i < spaceBelowTitle; i++)
            output += '║' + new string(' ', this._width-2) + "║\n";

        // add command buttons
        foreach (CommandButton button in this._buttons)
        {
            string[] buttonLines = button.GenerateButtonString();
            int horizontalButtonMargin = (this._width-2-button.GetWidth())/2;

            foreach (string buttonLine in buttonLines)
                output += '║' + new string(' ', horizontalButtonMargin) + buttonLine + new string(' ', horizontalButtonMargin) + (buttonLine.Length%2 == 0 ? "" : " ") + "║\n";
        }

        // complete remaining space with ' ';
        int remainingLines = this._height-topMargin-3-spaceBelowTitle-this._buttons.Count*3;
        for (int i = 0; i < remainingLines-1; i++)
            output += '║' + new string(' ', this._width-2) + "║\n";

        // last line
        output += '╚' + new string('═', this._width-2) + '╝';

        this._canvas.Write(output, this._canvas.GetBufferWidth(), this._canvas.GetHeight()-this._height); // Bulle de dialogue supprimer cette ligne et uncomment en haut
    }

    public override int GetHeight() => this._height;
    public override int GetWidth() => this._width;

    public void UpdateSelectedButton()
    {
        // unselect all button
        foreach (CommandButton button in this._buttons)
            button.Selected = false;

        // select the correct button
        this._buttons[this.Selected].Selected = true;
    }

    public void ResetButtonsList()
    {
        this._buttons = new List<CommandButton>();

        foreach (Command command in this.DefaultCommands)
            this._buttons.Add(new CommandButton(
            command.Name,
            () =>
            {
                if (command.AvailibleArgs.Length == 0)
                {
                    this._commandManager.ExecuteCommand(command, Array.Empty<string>());
                    ResetButtonsList();
                }
                else
                {
                    command.GetNewCommandButtons( newButtons => {
                        this._buttons = newButtons;

                        // add the exit button
                        this._buttons.Add(new CommandButton("Exit the command", ResetButtonsList));
                    });
                }
            }
            ));

        this.Selected = 0;

        Update();
    }
}


public class CommandButton
{
    public bool Selected;
    public string Label;
    public Action Action;

    private int _width = 30;

    public CommandButton(string label, Action action)
    {
        this.Label = label;
        this.Selected = false;
        this.Action = action;
    }

    public string[] GenerateButtonString() {

        string[] output = new string[3];

        // top border
        output[0] = '┌' + new string('─', this._width-2) + "┐";

        // label
        int horizontalMargin = (this._width-this.Label.Length)/2 - 1;
        output[1] = '│' + new string(' ', horizontalMargin) + this.Label + new string(' ', this._width-2-horizontalMargin-this.Label.Length-1) + (this.Selected ? '>' : ' ') + "│";

        // bottom border
        output[2] = '└' + new string('─', this._width-2) + '┘';

        return output;
    }

    public int GetWidth() => this._width;
}