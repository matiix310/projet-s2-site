using ProjS2.TerminalGame.Commands;
using ProjS2.Utils;

namespace ProjS2.TerminalGame;

public class CommandManager : Drawable {
    
    private readonly Canvas _canvas;
    private readonly Terminal _terminal;
    private readonly int _width;
    private readonly int _height;
    private readonly string _prefix = "$";
    
    private List<string> _commands;
    
    public CommandManager(Canvas canvas, Terminal terminal, int width, int height)
    {
        this._commands = new List<string>();
        this._canvas = canvas;
        this._terminal = terminal;
        this._width = width;
        this._height = height;
    }
    
    public override void Draw()
    {
        int leftMargin = 1;
        string output = String.Join("\n\n", this._commands);
        output = Common.FillWithSpaces(output, this._width-leftMargin, this._height);
        this._canvas.Write(output, leftMargin, 0);
    }

    public override int GetHeight() => this._height;

    public override int GetWidth() => this._width;
    
    private void TrimCommands()
    {
        int totHeight = 0;
        int i = 0;
        while (i < this._commands.Count)
        {
            // + 1 for the spacing
            int commandHeight = Common.GetStringSize(this._commands[i]).Height + 1;
            while (commandHeight + totHeight > this._height)
            {
                // trim the first command and next to let the place to the last command
                int firstCommandHeight = Common.GetStringSize(this._commands[0]).Height + 1;
                
                if (commandHeight < firstCommandHeight)
                {
                    // trim the first command
                    int toRemove = firstCommandHeight - commandHeight;
                    List<string> firstCommand = this._commands[0].Split('\n').ToList();
                    this._commands[0] = String.Join('\n', firstCommand.GetRange(toRemove, firstCommand.Count - toRemove));

                    totHeight -= toRemove;

                } else
                {
                    // remove the first command
                    this._commands = this._commands.GetRange(1, this._commands.Count-1);
                    totHeight -= firstCommandHeight;
                }
            }
            
            totHeight += commandHeight;
            i += 1;
        }
    }
    
    public void ExecuteCommand(Command command, string[] args)
    {
        this._commands.Add(this._terminal.Username + ": " + this._prefix + ' ' + command.Name + ' ' + String.Join(' ', args) + '\n' + command.Execute(args));
        TrimCommands();
        this._terminal.Update();
    }
}