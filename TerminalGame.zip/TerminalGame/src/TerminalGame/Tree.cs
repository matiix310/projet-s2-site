using ProjS2.Utils;

namespace ProjS2.TerminalGame;

public class Tree : Drawable {

    private readonly Canvas _canvas;
    private readonly int _width;
    private readonly int _height;
    private readonly LoadedStage _loadedStage;

    public Tree(Canvas canvas, int width, int height, LoadedStage loadedStage) {
        this._canvas = canvas;
        this._width = width;
        this._height = height;
        this._loadedStage = loadedStage;
    }

    public override void Draw() {
        string panelStr = "";
        string treeStr = GetTree(this._loadedStage.folders, "");

        // compute tree Size & margins
        (int Width, int Height)        treeSize = Common.GetStringSize(treeStr);
        (int Vertical, int Horizontal) margin   = ((this._height - treeSize.Height) / 2, (this._width - treeSize.Width-2) / 2);

        // first line
        panelStr += '╔' + new string('═', this._width-2) + "╗\n";

        // add top
        for (int i = 0; i < margin.Vertical-1; i++) {
            panelStr += '║' + new String(' ', this._width-2) + "║\n";
        }

        // add left & right
        string[] treeLines = treeStr.Split('\n');
        foreach (string line in treeLines)
            panelStr += "║" + new String(' ', margin.Horizontal) + line + new String(' ', this._width-2-line.Length-margin.Horizontal)+ "║\n";

        // add bottom
        for (int i = 0; i < margin.Vertical-((this._height-treeSize.Height)%2==0 ? 1 : 0); i++)
            panelStr += "║" + new String(' ', this._width-2) + "║\n";

        panelStr += "╠" + new String('═', this._width-2) + "╣";

        this._canvas.Write(panelStr, this._canvas.GetBufferWidth(), 0);
    }

    public static string GetTree(CustomFile[] folder, string start)
    {
        var dirs = folder.ToList().FindAll((cf => cf is { type: "folder", visible: true }));
        var files = folder.ToList().FindAll((cf => cf.type == "file" || !cf.visible));
        string output = "";

        foreach (CustomFile file in files)
        {
            output = output + "\n" + start + "|---" + FileManager.GetCfNameFormat(file);
        }

        for (int i = 0; i < dirs.Count-1; i++)
        {
            output = output + "\n" + start + "|---" + FileManager.GetCfNameFormat(dirs[i]) + GetTree(dirs[i].content, start + "|   ");
        }

        if (dirs.Count > 0) output = output + "\n" + start + "|---" + FileManager.GetCfNameFormat(dirs[^1]) + GetTree(dirs[^1].content, start + "    ");

        return output;
    }

    public override int GetHeight() => this._height;

    public override int GetWidth() => this._width;
}