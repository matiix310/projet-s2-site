using Timer = System.Timers.Timer;

namespace ProjS2.Utils;

public class InputListener {

    // the list of the listen keys
    private readonly Dictionary<ConsoleKey, Action> _handlers;
    // the state of the listening
    private bool _listening;
    // an instance of the Game to check if the game is still runing
    private Menu _game;

    public InputListener(Menu game)
    {
        this._game = game;
        this._handlers = new Dictionary<ConsoleKey, Action>();
    }

    /// <summary>Add an input to listen.</summary>
    /// <param name="key">The ConsoleKey you want to listen.</param>
    /// <param name="callback">The executed methode when the key is triggered.</param>
    public void ListenToInput(ConsoleKey key, Action callback)
    {
        if (_handlers.ContainsKey(key)) throw new Exception("This key is already listened : " + key.ToString());

        _handlers.Add(key, callback);
    }

    /// <summary>Remove an input to listen.</summary>
    /// <param name="key">The ConsoleKey you want to stop listening.</param>
    public void StopListeningToInput(ConsoleKey key)
    {
        if (_handlers.ContainsKey(key)) throw new Exception("This key is not listened : " + key.ToString());

        _handlers.Remove(key);
    }

    /// <summary>Start the listening loop until you call StopListening or ResetListenedKeys.</summary>
    public void StartMainThread()
    {
        _listening = true;

        // check if we are listening to keys and if the Game is still running
        while (this._game.IsGameRunning)
        {
            if (_listening && Console.KeyAvailable)
            {
                ConsoleKey keyPressed = Console.ReadKey(true).Key;

                // when a key is pressed and listened, we call the associated handler
                if (this._handlers.ContainsKey(keyPressed)) this._handlers[keyPressed].Invoke();
            }
        }
    }

    public void StartListening() => _listening = true;

    /// <summary>Stop listening to keys.</summary>
    public void StopListening() => _listening = false;

    /// <summary>Stop listening to keys and reset the stored keys.</summary>
    public void ResetListenedKeys()
    {
        _listening = false;
        _handlers.Clear();
    }
}