namespace ProjS2.Utils
{
    public class QuestUtils
    {

        /// <summary>Fetch all the quest from a .save file.</summary>
        /// <param name="cf">An instance of the configuration file.</param>
        public static QuestObject[] GetQuests(ConfigFile cf)
        {
            return LoadedStageUtils.GetLoadedStage().quests is null ? Array.Empty<QuestObject>() : LoadedStageUtils.GetLoadedStage().quests!;
        }

        /// <summary>Get a quest from the loaded save.</summary>
        /// <param name="cf">An instance of the configuration file.</param>
        /// <param name="id">The is of the quest you want.</param>
        /// <returns>the founded QuestObject with the specified id, null otherwise.</returns>
        public static QuestObject? GetQuest(ConfigFile cf, string id)
        {
            // récupère toutes les quêtes
            QuestObject[] quests = GetQuests(cf);

            // boucle sur toutes les quêtes
            for(int i = 0; i < quests.Length; i++)
            {
                // renvoi la bonne quête
                if(quests[i].id == id)
                {
                    return quests[i];
                }
            }

            // valeur de retour si rien n'est trouvé
            return null;
        }
    }
}