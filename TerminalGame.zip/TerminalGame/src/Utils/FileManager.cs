namespace ProjS2.Utils
{
    public class FileManager {

        /// <summary>Get the string content of a file</summary>
        /// <param name="path">The relative path, for example : assets/text.txt</param>
        public static string GetFile(string ?path) {
            if (path == null) return "null path (GetFile)";
            return String.Join('\n', File.ReadAllLines(Environment.CurrentDirectory + "/" + path));
        }

        /// <summary>
        /// Format a file / folder name depending on it's visibility / state
        /// </summary>
        /// <param name="cf">The CustomFile from wich you want the name.</param>
        public static string GetCfNameFormat(CustomFile cf)
        {
            string name;

            if (!cf.visible)
                name = new String('#', cf.name.Length);

            else if (cf.state == "locked")
                name = "[" + cf.name + (cf.type == "folder" ? "\\" : "") + "]";

            else if (cf.type == "folder")
                name = cf.name + "\\";

            else name = cf.name;

            return name;
        }

        /// <summary>Get the config file with a static context</summary>
        public static ConfigFile GetConfigFile()
        {
            return new Config().GetConfig<ConfigFile>("config.json")!;
        }
    }
}