using System.Text.Json;

namespace  ProjS2.Utils;

public class LoadedStageUtils {

    public static LoadedStage GetLoadedStage()
    {
        return new Config().GetConfig<LoadedStage>(FileManager.GetConfigFile().paths?.loadedStage)!;
    }

    public static void Save(LoadedStage loadedStage)
    {
        string jsonString = JsonSerializer.Serialize(loadedStage);
        // DEBUG
//        File.WriteAllText(cf.paths.loadedStage, jsonString);
        File.WriteAllText(FileManager.GetConfigFile().paths.loadedStage, jsonString);
    }

    public static LoadedStage GetResetStage()
    {
        return new Config().GetConfig<LoadedStage>(FileManager.GetConfigFile().paths?.resetStage)!;
    }

}

// the prototype of a .save file

public class LoadedStage
{
    public CustomFile[]? folders { get; set; }
    public bool firstLaunch { get; set; }
    public bool isKing { get; set; }
    public ItemObject[]? inventory { get; set; }
    public QuestObject[]? quests { get; set; }
    public string[]? unlockedCommands { get; set; }
    public bool hasPet { get; set; }
    public ScriptObject? script { get; set; }
}

public class ItemObject {
    public string id { get; set; }
    public string name { get; set; }
    public string description { get; set; }
    public int quantity { get; set; }
}

public class CustomFile {
    public string name { get; set; }
    public bool visible { get; set; }
    public string type { get; set; }
    public string state { get; set; }
    public CustomFile[] content { get; set; }
    public string textContent { get; set; }
}

public class QuestObject
{
    public string id { get; set; }
    public string name { get; set; }
    public string description { get; set; }
    public string questOwner { get; set; }
    public int progress { get; set; }
    public int successCondition { get; set; }
    public string neededItem { get; set; }
}

public class ScriptObject
{
    public NPCObject[] npcs { get; set; }
    public DroppedItem[] droppedItems { get; set; }
}

public class NPCObject
{
    public string id { get; set; }
    public int state { get; set; }
}

public class DroppedItem : ItemObject
{
    public int x { get; set; }
    public int y { get; set; }
    public int mapIndex { get; set; }
}