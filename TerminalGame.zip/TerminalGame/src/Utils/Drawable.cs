namespace ProjS2.Utils;

/// <summary>An Object that can be displayed on the canvas.</summary>
public abstract class Drawable {

    /// <summary>
    /// Draw the object on the given canvas
    /// </summary>
    public abstract void Draw();

    /// <summary>
    /// Get the Height of this Drawable
    /// </summary>
    public abstract int GetHeight();

    /// <summary>
    /// Get the Width of this Drawable
    /// </summary>
    public abstract int GetWidth();
}