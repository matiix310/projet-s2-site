
using System.Timers;
using Timer = System.Timers.Timer;

namespace ProjS2.Utils
{
    public class TimerManager {

        /// <summary>Call the given methode after a delay</summary>
        /// <param name="callback">The methode you want to execute.</param>
        /// <param name="delay">The delay (in ms).</param>
        public static void SetTimeout(ElapsedEventHandler callback, int delay) {
            Timer timer = new Timer(delay);
            timer.Start();
            timer.Elapsed += callback;
            timer.AutoReset = false;
        }

        /// <summary>Call the given methode in indefinitely with a delay</summary>
        /// <param name="callback">The methode you want to execute.</param>
        /// <param name="interval">The delay between each call (in ms).</param>
        public static Timer? SetInterval(ElapsedEventHandler callback, int interval)
        {
            // Create a timer with a two second interval.
            Timer? aTimer = new Timer(interval);

            // Hook up the Elapsed event for the timer. 
            aTimer.Elapsed += callback;
            aTimer.AutoReset = true;
            aTimer.Enabled = true;
            return aTimer;
        }
    }
}