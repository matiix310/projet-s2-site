
namespace ProjS2.Utils;

public class Common {

    /// <summary>Create a new string with the specified string being repeated.</summary>
    /// <param name="str">The string you want to repeat.</param>
    /// <param name="count">How many times you want your string to be repeated.</param>
    public static string Repeat(string str, int count) {
        string output = "";

        for (int i = 0; i < count; i++) {
            output += str;
        }

        return output;
    }

    /// <summary>Get the string height wand width.</summary>
    /// <param name="str">The given string you want to know the width and height.</param>
    public static (int Width, int Height) GetStringSize(string str)
    {
        string[] splitted = str.Split("\n");
        int width = 0;

        foreach (string line in splitted)
            if (width < line.Length) width = line.Length;

        return (width, splitted.Length);
    }

    public static string GenerateButton(string label, int width, int height)
    {
        string button = '╭' + new string('─', width-2) + "╮\n";

        for (int i = 1; i < height-1; i++)
        {
            if (i == height/2)
            {
                int margin = width-2 - label.Length;
                button += '│' + new string(' ', margin/2) + label + new string(' ', margin/2 + margin%2) + "│\n";
            }
            else
            {
                button += '│' + new string(' ', width-2) + "│\n";
            }
        }

        button += '╰' + new string('─', width-2) + '╯';

        return button;
    }

    public static string FillWithSpaces(string original, int width, int height)
    {
        List<string> originalSplit = original.Split('\n').ToList();

        // fill horizontally
        for (int i = 0; i < originalSplit.Count; i++)
            originalSplit[i] += new string(' ', width - originalSplit[i].Length);

        // fill vertically
        for (int i = originalSplit.Count; i < height; i++)
            originalSplit.Add(new string(' ', width));

        return string.Join('\n', originalSplit);
    }
}