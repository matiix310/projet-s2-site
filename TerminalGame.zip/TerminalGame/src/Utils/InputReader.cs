namespace ProjS2.Utils;

public class InputReader
{
    
    public static string? Read(Canvas canvas, Menu menu, string question)
    {
        (int Width, int Height) buttonSize = (50, 5);
        
        // clear the canvas
        menu.SetCanvasUpdateState(false);
        canvas.Clear();
        
        // generate the button
        string leftMargin = new string(' ', (canvas.GetWidth() - buttonSize.Width) / 2);
        string textInput = '┏' + new string('━', buttonSize.Width-2) + "┓\n";
        
        for (int i = 0; i < buttonSize.Height-2; i++)
            textInput += leftMargin + '┃' + new string(' ', buttonSize.Width-2) + "┃\n";
        
        textInput += leftMargin + '┗' + new string('━', buttonSize.Width-2) + '┛';
        
        // draw the text input
        Console.SetCursorPosition((canvas.GetWidth() - question.Length) / 2, (canvas.GetHeight() - buttonSize.Height) / 2 - 3);
        Console.Write(question);
        Console.SetCursorPosition((canvas.GetWidth() - buttonSize.Width) / 2, (canvas.GetHeight() - buttonSize.Height) / 2 + 1);
        Console.Write(textInput);
        
        // get the input string
        Console.SetCursorPosition((canvas.GetWidth() - buttonSize.Width) / 2 + 3, canvas.GetHeight() / 2);
        Console.CursorVisible = true;
        string? input = Console.ReadLine();
        Console.CursorVisible = false;
        
        if (input is null || input.Trim() == "")
            return Read(canvas, menu, question);
        
        // resume the canvas update
        menu.SetCanvasUpdateState(true);
        return input;
    }
}