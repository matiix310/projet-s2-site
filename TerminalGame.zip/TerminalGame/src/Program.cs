﻿
using System.Text;
using ProjS2;

internal class Program
{
    static void Main(string[] args)
    {
//        Game game = new Game(234, 52, 180);
//        game.Start();
        Console.OutputEncoding = Encoding.UTF8;
        Menu menu = new Menu(234, 52, 180);
        menu.Start();
    }

}