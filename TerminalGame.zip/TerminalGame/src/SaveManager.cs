using ProjS2.RpgGame;
using ProjS2.RpgGame.Quest;
using ProjS2.TerminalGame;
using ProjS2.TerminalGame.Commands;
using ProjS2.Utils;

namespace ProjS2;

public class SaveManager {
    
    public readonly int MapCount = 5;
    private readonly Canvas _canvas;

    private Rpg? _rpg;
    private Terminal? _terminal;
    private Game _game;

    public LoadedStage LoadedStage;
    
    public SaveManager(Canvas canvas, Game game)
    {
        this.LoadedStage = LoadedStageUtils.GetLoadedStage();
        this._canvas = canvas;
        this._game = game;
    }
    
    public void Save()
    {
        if (this.LoadedStage is null)
            throw new NullReferenceException("Can't save a null stage ! You have to load the stage before saving it.");
        
        // save the NPCS
        if (this._rpg is not null)
        {
            SaveNpcs();
            SaveDroppedItems();
            SaveInventory();
            SaveQuests();
            this.LoadedStage.hasPet = this._rpg.HasPet;
            this.LoadedStage.isKing = this._game.IsKing;
        }

        if (this._terminal is not null)
        {
            SaveCommands();
        }

        this.LoadedStage.firstLaunch = false;

        LoadedStageUtils.Save(this.LoadedStage);
    }

    private void SaveCommands()
    {
        List<string> commandsName = new List<string>();

        foreach (Command command in this._terminal!.CommandSelector.DefaultCommands)
            commandsName.Add(command.Name);

        this.LoadedStage.unlockedCommands = commandsName.ToArray();
    }

    private void SaveNpcs()
    {
        List<NPCObject> npcs = new List<NPCObject>();

        foreach (List<NPC> npcList in this._rpg!.NPCs)
            foreach (NPC npc in npcList)
            {
                npcs.Add(new NPCObject()
                {
                    id = npc.Id,
                    state = npc.State
                });
            }

        this.LoadedStage.script!.npcs = npcs.ToArray();
    }

    private void SaveDroppedItems()
    {
        List<DroppedItem> items = new List<DroppedItem>();

        for (int i = 0; i < this._rpg!.Items.Count; i++)
        {
            foreach (Item item in this._rpg.Items[i])
            {
                items.Add(new DroppedItem()
                {
                    id = item.Id,
                    x = item.X,
                    y = item.Y,
                    name = item.Name,
                    mapIndex = i,
                    quantity = item.Quantity,
                    description = item.Description
                });
            }
        }

        this.LoadedStage.script!.droppedItems = items.ToArray();
    }

    private void SaveInventory()
    {
        List<ItemObject> items = new List<ItemObject>();

        foreach (ItemObject item in this._rpg.Inventory.GetItems())
            items.Add(new ItemObject()
            {
                id = item.id,
                name = item.name,
                quantity = item.quantity,
                description = item.description
            });

        this.LoadedStage.inventory = items.ToArray();
    }

    private void SaveQuests()
    {
        this.LoadedStage.quests = this._rpg!.QuestManager.QuestlList.ToArray();
    }

    public void LoadRpgComponents(Rpg rpg, QuestManager questManager)
    {
        this._rpg = rpg;
        LoadInventory();
        LoadNpcs(questManager);
        LoadItems();
        rpg.HasPet = this.LoadedStage.hasPet;
    }

    public void LoadTerminalComponents(Terminal terminal)
    {
        this._terminal = terminal;
        LoadCommands();

        // check if the player is root (king)
        if (this.LoadedStage.isKing)
            terminal.Username = "root";
    }

    private void LoadCommands()
    {
        foreach (string commandName in this.LoadedStage.unlockedCommands)
            this._terminal.CommandSelector.DefaultCommands.Add(this._terminal.CommandSelector.ParseCommand(commandName));
    }

    private void LoadNpcs(QuestManager questManager)
    {
        this._rpg!.NPCs = new List<List<NPC>>();
        for (int i = 0; i < this.MapCount; i ++)
            this._rpg.NPCs.Add(new List<NPC>());

        ConfigFile configFile = FileManager.GetConfigFile();

        foreach (NPCObject npcObject in this.LoadedStage.script!.npcs)
        {
            switch (npcObject.id)
            {
                // Guard in front of the Castle outer court
                case "castleGuard" :
                    QuestObject castleGuardQuest = new QuestObject()
                    {
                        id = "castGuardQuest",
                        name = "Gather 10 gold pieces",
                        description = "Buy the entrance guard with 10 gold pieces to enter the outer court of the castle.",
                        questOwner = "A respectfull entrance guard",
                        successCondition = 10,
                        neededItem = "gold_piece"
                    };
                    NPC castleGuard = new NPC(this._canvas, 642, 157, npcObject.id, "A respectfull entrance guard", FileManager.GetFile(configFile.paths.images.guard01), this._rpg, new string[]
                        {
                            "It is impossible to enter without an autorisation !\nBut if you have 10 gold pieces, we can negociate...\n[Press SPACEBAR to accept the quest]",
                            "I can't let you enter this place without an autorisation !\n[Press SPACEBAR to complete the quest]",
                            "{To enter the outer court you have to get back to the terminal and cd into it.}"
                        },
                        state =>
                        {
                            // give the quest
                            if (state == 0)
                            {
                                questManager.AddQuest(castleGuardQuest);
                                return state += 1;
                            }

                            // complete the quest
                            if (state == 1 && this._rpg.Inventory.RemoveItem("gold_piece", 10))
                            {
                                questManager.RemoveQuest(castleGuardQuest.id);
                                foreach (string shopName in new string[] { "Antique_dealer", "Flower_shop", "Wine_shop", "Snake_shop" })
                                    EditCustomFileStateAndVisibility(new List<string>()
                                        { "Outer_court", shopName },
                                        "unlocked",
                                        true);

                                EditCustomFileStateAndVisibility(new List<string>()
                                    { "Outer_court", "Secret_door" },
                                    "locked",
                                    true);

                                EditCustomFileStateAndVisibility(new List<string>()
                                    { "Outer_court" },
                                    "unlocked",
                                    true);

                                EditCustomFileStateAndVisibility(new List<string>()
                                    { "Outer_court", "Castle" },
                                    "locked",
                                    true);

                                this._rpg.DisplayHint("You have unlocked the Outer court of the Castle !\nTo enter it, go back into the terminal and go inside the Outer_court folder.", 10000);
                                return state += 1;
                            }

                            return state;
                        });
                    castleGuard.State = npcObject.state;
                    this._rpg.NPCs[0].Add(castleGuard);
                    break;

                case "wanderingMerchant":
                    QuestObject getRustySword = new QuestObject()
                    {
                        id = "getRustySword",
                        name = "Find a tradable item",
                        neededItem = "rusty_sword",
                        questOwner = "Wandering merchant",
                        description = "Find an item to trade with the wandering merchant.",
                        successCondition = 1
                    };
                    NPC wanderingMerchant = new NPC(this._canvas, 100, 207, npcObject.id, "Wandering merchant", "", this._rpg, new string[]
                        {
                            "I'm missing some new items, can you help me to fulfill my stock ?\n[Press SPACEBAR to accept the quest]",
                            "Do you have something valuable to trade me ?\n[Press SPACEBAR to complete the quest]",
                            "This sword is amazing !"
                        },
                        state =>
                        {
                            // give the quest
                            if (state == 0)
                            {
                                questManager.AddQuest(getRustySword);
                                return state += 1;
                            }

                            // complete the quest
                            if (state == 1 && this._rpg.Inventory.RemoveItem("rusty_sword", 1))
                            {
                                questManager.RemoveQuest(getRustySword.id);
                                this._rpg.Inventory.AddItem("hydra_book", "Hydra book", "An ancient book that is capable of miracle.", 1);

                                // give the hydra command to the player
                                this._terminal.CommandSelector.DefaultCommands.Add(this._terminal.CommandSelector.ParseCommand("hydra"));

                                this._rpg.DisplayHint("The Wandering merchant trades you the \"Hydra book\"!\nThis book give you the ability to find a password\nby testing all the possible combinations.", 10000);
                                return state += 1;
                            }

                            return state;
                        });
                    wanderingMerchant.State = npcObject.state;
                    this._rpg.NPCs[1].Add(wanderingMerchant);
                    break;

                case "secretDoor":
                    NPC secretDoor = new NPC(this._canvas, 499, 132, npcObject.id, "Secret door", FileManager.GetFile(configFile.paths.images.secretDoor), this._rpg, new string[]
                        {
                            "The door is locked with a password",
                            "To enter the castle you have to go into\nthe Castle folder from the terminal"
                        },
                        state => state);

                    secretDoor.State = npcObject.state;
                    this._rpg.NPCs[1].Add(secretDoor);
                    break;

                case "snakeVendor":
                    QuestObject snakeVendorQuest1 = new QuestObject()
                    {
                        id = "getHat",
                        name = "Get a hat in the forest hut",
                        neededItem = "hat",
                        questOwner = "Snake vendor",
                        description = "Bring back the snake vendor's hat from his hut.",
                        successCondition = 1
                    };
                    QuestObject snakeVendorQuest2 = new QuestObject()
                    {
                        id = "get10pSnake",
                        name = "Gather 10 gold pieces",
                        description = "You need to gather 10 gold pieces to buy a snake.",
                        questOwner = "Snake vendor",
                        successCondition = 10,
                        neededItem = "gold_piece"
                    };
                    NPC snakeVendor = new NPC(this._canvas, 475, 207, npcObject.id, "Snake vendor", "", this._rpg, new string[]
                        {
                            "I sell beautyful snakes for 20 gold pieces each!\nBut I'm forget to take my hat in my hut in the forest...\n[Press SPACEBAR to accept the quest]",
                            "Did you find my hat?\n[Press SPACEBAR to complete the quest]",
                            "Thanks a lot, with this sunny weather, I was litteraly melting.\nIf you want, I can sell you a python for only 10 gold pieces!\n[Press SPACEBAR to accept the quest]",
                            "Do you want to buy me a python for 10 gold pieces?\n[Press SPACEBAR to complete the quest]",
                            "Thanks for buying me a python."
                        },
                        state =>
                        {
                            // give the quest
                            if (state == 0)
                            {
                                questManager.AddQuest(snakeVendorQuest1);
                                this._rpg.Inventory.AddItem("hut_key", "Hut key", "The key of the hidden hut in the forest", 1);
                                return 1;
                            }

                            // complete the quest
                            if (state == 1 && this._rpg.Inventory.RemoveItem("hat", 1))
                            {
                                questManager.RemoveQuest(snakeVendorQuest1.id);
                                return 2;
                            }

                            // give the new quest
                            if (state == 2)
                            {
                                questManager.AddQuest(snakeVendorQuest2);
                                return 3;
                            }

                            // complete the new quest
                            if (state == 3 && this._rpg.Inventory.RemoveItem("gold_piece", 10))
                            {
                                questManager.RemoveQuest(snakeVendorQuest2.id);

                                // give the pet and make it spawn at the default player span
                                this._rpg.HasPet = true;
                                this._rpg.Pet.SetPos(this._rpg.GetPlayerRpg().pos.X, this._rpg.GetPlayerRpg().pos.Y + 10);
                                this._rpg.Pet.StartFollowing(this._rpg.GetPlayerRpg());

                                // give the python command to the player
                                this._terminal.CommandSelector.DefaultCommands.Add(this._terminal.CommandSelector.ParseCommand("python"));

                                this._rpg.DisplayHint("You now have a new companion for your journey.\nHis name is python and might be really useful.", 10000);
                                return 4;
                            }

                            return state;
                        });
                    snakeVendor.State = npcObject.state;
                    this._rpg.NPCs[1].Add(snakeVendor);
                    break;

                case "hutDoor":
                    NPC hutDoor = new NPC(this._canvas, 443, 51, npcObject.id, "Hut door", "", this._rpg, new string[]
                        {
                            "The door is locked, you need the key\n[Press SPACEBAR to unlock the door]",
                            "To enter the hut you have to go into\nthe Hut folder from the terminal"
                        },
                        state =>
                        {
                            if (state == 0 && this._rpg.Inventory.RemoveItem("hut_key", 1))
                            {
                                EditCustomFileStateAndVisibility(new List<string>() { "Hut" }, "unlocked", true);
                                return 1;
                            }

                            return state;
                        });

                    hutDoor.State = npcObject.state;
                    this._rpg.NPCs[0].Add(hutDoor);
                    break;
            }
        }
    }

    private void LoadItems()
    {
        this._rpg!.Items = new List<List<Item>>();
        for (int i = 0; i < this.MapCount; i ++)
            this._rpg.Items.Add(new List<Item>());

        ConfigFile configFile = FileManager.GetConfigFile();

        Dictionary<string, (string Little, string Big)> itemsAssets = new Dictionary<string, (string Little, string Big)>()
        {
            {"gold_piece", (FileManager.GetFile(configFile.paths.images.itemCoinLittle), FileManager.GetFile(configFile.paths.images.itemCoinBig))},
            {"rusty_sword", (FileManager.GetFile(configFile.paths.images.itemRustySwordLittle), FileManager.GetFile(configFile.paths.images.itemRustySwordBig))},
            {"hat", (FileManager.GetFile(configFile.paths.images.itemHatLittle), FileManager.GetFile(configFile.paths.images.itemHatBig))},
            {"tablet", (FileManager.GetFile(configFile.paths.images.itemTabletLittle), FileManager.GetFile(configFile.paths.images.itemTabletBig))}
        };

        foreach (DroppedItem droppedItem in this.LoadedStage.script!.droppedItems)
        {
            Item goldPiece = new Item(
                this._canvas,
                droppedItem.x,
                droppedItem.y,
                droppedItem.quantity,
                droppedItem.description,
                droppedItem.name,
                droppedItem.id,
                itemsAssets[droppedItem.id].Little,
                itemsAssets[droppedItem.id].Big,
                this._rpg);
            this._rpg.Items[droppedItem.mapIndex].Add(goldPiece);
        }
    }

    private void LoadInventory()
    {
        foreach (ItemObject item in this.LoadedStage.inventory!)
        {
            this._rpg!.Inventory.AddItem(
                item.id,
                item.name,
                item.description,
                item.quantity);
        }
    }

    public void EditCustomFileStateAndVisibility(List<string> location, string state, bool visible)
    {
        CustomFile file = this.LoadedStage.folders![0];

        foreach(string fileName in location)
            file = file.content.ToList().Find(cf => cf.name == fileName)!;

        file.state = state;
        file.visible = visible;
    }
}