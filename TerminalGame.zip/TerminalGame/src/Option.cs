﻿using ProjS2.TerminalGame;
using ProjS2.Utils;

namespace ProjS2;

public class Option
{
    private readonly InputListener _inputListener;
    private readonly Canvas _canvas;
    private Menu _menu;
    private int _fps;
    private CommandButton[] _commandButtons;

    public Option(Canvas canvas, InputListener input, Menu menu)
    {
        _inputListener = input;
        _canvas = canvas;
        _menu = menu;
    }

    public void Draw()
    {
        string? input = InputReader.Read(_canvas, _menu, "Set your FPS (currently " + this._menu.Fps + ") :");
        if (Int32.TryParse(input, out int fps))
        {
            this._menu.Fps = fps;
            _canvas.Clear();
            this._menu.RestartActualisationThread();
        }
        _menu.DisplayMenu();
    }
}